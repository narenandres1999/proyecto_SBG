<?php

namespace Database\Factories;

use App\Models\Usuario;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Foro>
 */
class ForoFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $keys = Usuario::all()->modelKeys();
        return [
            'titulo' => $this->faker->title(),
            'descripcion' => $this->faker->paragraph(),
            'usuario_id' => $this->faker->randomElement($keys)
        ];
    }
}
