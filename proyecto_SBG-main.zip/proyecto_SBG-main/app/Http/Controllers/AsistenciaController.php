<?php

namespace App\Http\Controllers;

use App\Models\Asistencia;
use App\Models\Usuario;
use Illuminate\Http\Request;

class AsistenciaController extends Controller
{
    public function index()
    {
        $events = array();
        $entrenadores = Usuario::role('Entrenador')->orderBy('apellidos')->get();
        $asistencias = Asistencia::all();
        foreach($asistencias as $asistencia) {
            $title = $asistencia->horas.'h '.$asistencia->usuario->apellidos.' '.$asistencia->usuario->nombre;
            $events[] = [
                'id'   => $asistencia->id,
                'title' => $title,
                'start' => $asistencia->start_date,
                'end' => $asistencia->end_date,
                'color' => $asistencia->color ? $asistencia->color: '#924ACE',
                "allDay"=> !0
            ];
        }
        return view('trainers.asistence.index', compact('events','entrenadores'));
    }
    public function store(Request $request)
    {
        $request->validate([
            'usuario_id' => 'required|string',
            'horas' => 'required|numeric'
        ]);

        $asistencia = Asistencia::create([
            'horas' => $request->horas,
            'color' => $request->color,
            'usuario_id' => $request->usuario_id,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
        ]);
        $title = $asistencia->usuario->apellidos.' '.$asistencia->usuario->nombre;
        return response()->json([
            'id' => $asistencia->id,
            'start' => $asistencia->start_date,
            'end' => $asistencia->end_date,
            'title' => $title,
            'color' => $asistencia->color ? $asistencia->color: '',
        ]);
    }
    public function update(Request $request, $id)
    {
        $asistencia = Asistencia::find($id);

        if (!$asistencia) {
            return response()->json([
                'error' => 'Unable to locate the event'
            ], 404);
        }

        $asistencia->start_date = $request->start_date;

        if ($request->has('end_date')) {
            $asistencia->end_date = $request->end_date;
        }

        $asistencia->save();

        return response()->json('Event updated');
    }

    public function destroy($id)
    {
        $asistencia = Asistencia::find($id);
        if(! $asistencia) {
            return response()->json([
                'error' => 'Unable to locate the event'
            ], 404);
        }
        $asistencia->delete();
        return $id;
    }
}
