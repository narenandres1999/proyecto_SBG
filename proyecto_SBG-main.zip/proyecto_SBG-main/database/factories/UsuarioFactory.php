<?php

namespace Database\Factories;

use App\Models\Membresia;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Usuario>
 */
class UsuarioFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {   $membresia = Membresia::all()->modelKeys();
        return [
            'email' => $this->faker->unique()->email(),
            'email_verified_at' => now(),
            'password' => Hash::make('password'),
            'telefono' => $this->faker->phoneNumber(),
            'fecha_nacimiento' => $this->faker->dateTime(),
            'nombre' => $this->faker->firstName(),
            'apellidos' => $this->faker->lastName(),
            'avatar' => 'avatar'.$this->faker->numberBetween(100,199).'.jpg',
            'direccion' => $this->faker->streetAddress(),
            'membresia_id' => $this->faker->randomElement($membresia),
            'proxima_generacion' => null,
            'presentacion' => $this->faker->paragraph(4),
            'type_identification_id' => 1,
            'documento' => strval($this->faker->numberBetween(1100000000,1300000000)),
            'suscripcion_activa' => 0
        ];
    }
}
