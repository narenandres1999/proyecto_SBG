<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('usuarios', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('documento')->nullable();
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('telefono')->nullable();
            $table->date('fecha_nacimiento');
            $table->text('presentacion')->nullable();
            $table->string('nombre');
            $table->string('apellidos');
            $table->string('avatar')->nullable();
            $table->string('direccion')->nullable();
            $table->date('proxima_generacion')->nullable();
            $table->integer('suscripcion_activa')->nullable(); // Solo sera nula para los usuarios que no son clientes
            $table->softDeletes();
            $table->rememberToken();
            $table->timestamps();
            // Relaciones
            $table->foreignId('type_identification_id')->nullOnDelete()->nullable()->constrained();
            $table->foreignId('membresia_id')->nullOnDelete()->nullable()->constrained();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('usuarios');
    }
};
