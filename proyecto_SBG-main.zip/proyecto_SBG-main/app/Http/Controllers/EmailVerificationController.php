<?php

namespace App\Http\Controllers;

use App\Models\Usuario;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\EmailVerificationRequest;
use Exception;
use Illuminate\Auth\Events\Verified;
use Illuminate\Support\Facades\Auth;

class EmailVerificationController extends Controller
{
    public function index()
    {
        return view('auth.verify-email');
    }

    public function verificar(Request $request)
    {
        try {
            Auth::loginUsingId(['id' => $request->route('id')]);
            if (! $request->user()->hasVerifiedEmail()) {
                $request->user()->markEmailAsVerified();
                event(new Verified($request->user()));
            }
            return redirect()->route('landing.index')->with('alert', ['type' => 'success']);
        } catch (Exception $e) {
            throw $e;
            return back()->with('alert', ['type' => 'error']);
        }
    }

    public function reenviarCorreo(Request $request)
    {
        try {
            $request->user()->sendEmailVerificationNotification();
            return redirect()->route('landing.index')->with('alert', ['type' => 'success']);
        } catch (Exception $e) {
            throw $e;
            return back()->with('alert', ['type' => 'error']);
        }
    }
}
