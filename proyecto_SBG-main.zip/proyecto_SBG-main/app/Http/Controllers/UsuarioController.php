<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreUsuarioRequest;
use App\Http\Requests\UpdateUsuarioRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Notification;
use App\Models\Usuario;
use App\Http\Resources\UsuarioResource;
use App\Models\Membresia;
use App\Models\TypeIdentification;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Hash;
use PhpParser\Node\Expr\Cast\Object_;
use Spatie\Permission\Models\Role;
use function GuzzleHttp\Promise\all;
use function PHPUnit\Framework\isEmpty;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Exception;
use Symfony\Component\Console\Output\Output;
use Illuminate\Auth\Events\Registered;
use Illuminate\Database\Eloquent\Builder;

class UsuarioController extends Controller
{
    // Este método muestra los usuarios dependiendo del rol
    // ruta = /usuarios/{role?}
    public function index(Request $r, string $role = null)
    {
        $fecha_actual = new Carbon(now());
        $search = $r->search;
        $usuarios_cliente = Usuario::role('Cliente')->count();
        $usuarios_entrenador = Usuario::role('Entrenador')->count();
        $usuarios_admin = Usuario::role('Admin')->count();
        $usuarios_totales = Usuario::count();
        $clientes_recientes = Usuario::role('Cliente')->whereMonth('created_at', $fecha_actual->month)->whereYear('created_at', $fecha_actual->year)->get()->count();
        $usuarios_inactivos = Usuario::onlyTrashed()->count();
        if ($role) {
            $usuarios = Usuario::where('nombre', 'ilike', '%' . $search . '%')
                ->orWhere('apellidos', 'ilike', '%' . $search . '%')
                ->orWhere('email', 'ilike', '%' . $search . '%')
                ->orWhere('documento', 'ilike', '%' . $search . '%')
                ->role($role)
                ->orderBy('created_at', 'desc')
                ->paginate(10);
        } else {
            $usuarios = Usuario::where('nombre', 'ilike', '%' . $search . '%')
                ->orWhere('apellidos', 'ilike', '%' . $search . '%')
                ->orWhere('email', 'ilike', '%' . $search . '%')
                ->orWhere('documento', 'ilike', '%' . $search . '%')
                ->orderBy('created_at', 'desc')
                ->paginate(10);
        }

        return view('users.index', compact('role', 'usuarios', 'usuarios_cliente', 'usuarios_entrenador', 'usuarios_admin', 'usuarios_totales', 'clientes_recientes', 'usuarios_inactivos'));
    }
    public function entrenadores()
    {
        $entrenadores = Usuario::role('Entrenador')->paginate();
        return view('trainers.index', compact('entrenadores'));
    }
    // Este método muestra el formulario para crear nuevos usuarios
    // ruta = /usuarios/create
    public function create()
    {
        // Aqui va la vista para la creacion de un nuevo usuario
        $tipos_documentos = TypeIdentification::all();
        $membresias = Membresia::all();
        return view('users/create', compact('membresias', 'tipos_documentos'));
    }
    // Este método recibe la información del formulario y crea un nuevo usuario con el rol
    // Asginado a través de la url (pendiente de si cambiarlo a elemento del formulario )
    // ruta = /usuarios/{rol}
    public function store(StoreUsuarioRequest $request)
    {
        try {
            if ($request->documento) {
                $this->validate($request, [
                    'documento' => "required|numeric|digits_between:5,11"
                ]);
            }
            if ($request->role == ('Cliente')) {
                $request['suscripcion_activa'] = 1;
                $request['proxima_generacion'] = now();
            } else {
                $request['suscripcion_activa'] = 1;
                $request['proxima_generacion'] = null;
            }
            $input = $request->except(['role', 'password_confirm']);
            $input['password'] = Hash::make($input['password']);
            $role = $request->role;
            $registrado = Usuario::where('email', $input['email'])->count();
            if ($request->documento && !$request->type_identification_id) {
                back()->withErrors(['type_identification_id' => 'seleccione el tipo de documento'])->withInput($input);
                throw new Exception("");
            }
            if ($registrado > 0) {
                back()->withErrors(['email' => 'este correo está actualmente en uso'])->withInput($input);
                throw new Exception("");
            }
            $usuario = Usuario::create($input)->assignRole($request->role);
            $usuario->sendEmailVerificationNotification();
            return redirect()->route('usuarios.index', compact('role'))->with('alert', ['type' => 'success']);
        } catch (Exception $e) {
            if ($e->getMessage() != "") {
                throw $e;
                back()->with('alert', ['type' => 'error'])->withInput($request->all());
            }
            return back()->with('alert', ['type' => 'error'])->withInput($request->all());
        }
    }

    // Este método muestra la información de un solo usuario
    // ruta = /usuario/{usuario}
    public function show(Usuario $usuario)
    {
        $tipos_documentos = TypeIdentification::all();
        if ($usuario->hasRole('Entrenador')) {
            return view('trainers.show', compact('usuario','tipos_documentos'));
        } else {
            $usuario->antropometricas = $usuario->antropometricas()->paginate(5);
            $usuario->observaciones = $usuario->observaciones()->paginate(6);
            $usuario->historialPagos = $usuario->historialPagos()->paginate(5);
            $membresias_ofertadas = Membresia::all();
            $disabled = true;
            if (Auth::user()->roles[0]->name === 'Admin') {
                $disabled = false;
            }
            return view('users.edit', compact('usuario', 'membresias_ofertadas', 'disabled','tipos_documentos'));
        }
    }
    // Este método recoge la información recibida en el formulario y actualiza la
    // información de un usuario seleccionado
    // ruta = /usuario/{usuario}
    public function edit(Usuario $usuario)
    {
        $tipos_documentos = TypeIdentification::all();
        return view('trainers.edit', compact('usuario','tipos_documentos'));
    }

    public function update(UpdateUsuarioRequest $request, Usuario $usuario)
    {

        try {
            // Pendiente todas las especificaciones de valores validos en el formulario
            $input = $request->all();
            if (!empty($input['password'])) {
                $input['password'] = Hash::make($input['password']);
            } else {
                $input = Arr::except($input, array('password'));
            }
            $registrado = Usuario::where('email', $request->email)->count();
            if ($registrado > 0 && $usuario->email != $input['email']) {
                return back()->withErrors(['email' => 'Este correo está actualmente en uso'])->withInput($input);
            }
            if ($request->documento && !$request->type_identification_id) {
                back()->withErrors(['type_identification_id' => 'seleccione el tipo de documento'])->withInput($input);
                throw new Exception("");
            }
            $usuario->update($input);
            $usuario->fresh();
            return redirect()->back()->with('alert', ['type' => 'info']);
        } catch (Exception $e) {
            throw $e;
            return back()->with('alert', ['type' => 'error'])->withInput($request->all());
        }
    }
    public function updatePresentacion(Request $r, Usuario $usuario)
    {
        try {
            $this->validate($r, [
                'presentacion' => ''
            ]);
            $usuario->presentacion = $r->presentacion;
            $usuario->save();
            $controlador = new TituloAcademicoController();
            $controlador->update($r, $usuario);
            return redirect()->route('usuarios.show', $usuario)->with('alert', ['type' => 'info']);
        } catch (Exception $e) {
            throw $e;
            return back()->with('alert', ['type' => 'error'])->withInput($r->all());
        }
    }
    // Método para eliminar registros (temporalmente)
    // ruta = /usuario/{usuario}
    public function destroy(Usuario $usuario)
    {
        $usuario->delete();
    }

    public function listaBaneados(Request $r, string $role = null)
    {
        $search = $r->search;
        $usuarios_cliente = Usuario::onlyTrashed()->role('Cliente')->count();
        $usuarios_entrenador = Usuario::onlyTrashed()->role('Entrenador')->count();
        $usuarios_admin = Usuario::onlyTrashed()->role('Admin')->count();
        $usuarios_totales = Usuario::onlyTrashed()->count();
        if ($role) {
            $usuarios = Usuario::onlyTrashed()->where(function (Builder $query) use ($search) {
                $query->where('nombre', 'ilike', '%' . $search . '%')
                    ->orWhere('apellidos', 'ilike', '%' . $search . '%')
                    ->orWhere('email', 'ilike', '%' . $search . '%')->get();
            })->role($role)->paginate(10);
        } else {
            $usuarios = Usuario::onlyTrashed()->where(function (Builder $query) use ($search) {
                $query->where('nombre', 'ilike', '%' . $search . '%')
                    ->orWhere('apellidos', 'ilike', '%' . $search . '%')
                    ->orWhere('email', 'ilike', '%' . $search . '%')->get();
            })->paginate(10);
        }
        return view('inactive_users.index', compact('role', 'usuarios', 'usuarios_cliente', 'usuarios_entrenador', 'usuarios_admin', 'usuarios_totales'));
    }
    public function restaurarUsuario(string $usuario)
    {
        try {
            $usuario = Usuario::withTrashed()->find($usuario);
            $usuario->restore();
            return back()->with('alert', ['type' => 'restore']);
        } catch (Exception $e) {
            throw $e;
            return back()->with('alert', ['type' => 'error']);
        }
    }
    // Programador para reportar cuentas inactivas (Se tiene en cuenta que si un usuario no tiene una membresia activa, se eliminara el usuario)
    // Se usara con el sofdelete con la idea de que digamos por alguna razon el cliente inactivo ya tenia unos datos creados
    // Entonces el administrador podrá reestablecer la cuenta de dicho usuario si desea volver al gimnasio la etapa de espera es de 15 dias
    // Si es usuario nuevo y no ha comprado una membresia en los proximos 15 dias de haber creado la cuenta entonces se le eliminara

    public function reportarCuentas()
    {
        // Eliminar cuentas que han sido creadas pero no han adquirido ninguna membresia (plazo maximo para comprar de 15 dias)
        Usuario::role('Cliente')->where('membresia_id', null)->chunkById(100, function (Collection $usuarios) {
            foreach ($usuarios as $usuario) {
                // Este es para eliminar usuarios nuevos que no han comprado ninguna membresia antes
                if ($usuario->historialPagos->count() == 0) {
                    $plazo_limite = $usuario->created_at->addDays(15);
                    if ($plazo_limite <= now()) {
                        $usuario->forceDelete();
                    }
                }
                $plazo_limite = Carbon::parse($usuario->proxima_generacion);
                $plazo_limite = $plazo_limite->addDays(30);
                if (now() >= $plazo_limite) {
                    $usuario->delete();
                }
            }
        });
    }
}
