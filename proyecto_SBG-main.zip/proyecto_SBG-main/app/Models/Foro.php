<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\Usuario;
use Illuminate\Database\Eloquent\SoftDeletes;
class Foro extends Model
{
    use HasFactory;
    protected $guarded = [];
    // Definición de los métodos de relaciones
    public function usuario(): BelongsTo
    {
        return $this->belongsTo(Usuario::class);
    }
}
