<?php

namespace App\Http\Controllers;

use App\Mail\EventoMailable;
use App\Models\Evento;
use App\Models\Usuario;
use Exception;
use GuzzleHttp\Promise\Promise;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class EventoController extends Controller
{
    public function index(Request $request)
    {
        $eventos = Evento::whereDate('fecha_desde', '<=', now())
            ->whereDate('fecha_hasta', '>=', now())
            ->orderByDesc('created_at')
            ->get();
        return view('activities.index', compact('eventos'));
    }
    public function create()
    {
        return view('activities.create');
    }
    public function edit(Evento $evento)
    {
        return view('activities.edit', compact('evento'));
    }
    public function show(Evento $evento)
    {
        return view('activities.show', compact('evento'));
    }
    public function store(Request $request)
    {
        try {
            DB::beginTransaction();
            $this->validate($request, [
                'fecha_desde' => "required|date",
                'fecha_hasta' => "required|date|after_or_equal:fecha_desde",
                'titulo' => "required|string",
                'fecha_evento' => "required|date|before_or_equal:fecha_hasta",
                'imagen' => "image:jpg,jpeg,png,bmp",
                'contenido' => "required|string"
            ]);
            $filename = null;
            if ($request->imagen) {
                $folderPath = public_path('media/actividades/');
                $imagen = $request->file('imagen');
                $filename = Str::slug($request->titulo) . '_' . date('Ymd_His') . '.' . $imagen->guessExtension();
                $imagen->move($folderPath, $filename);
            }
            $evento = Evento::create([
                'titulo' => $request->titulo,
                'fecha_desde' => $request->fecha_desde,
                'fecha_evento' => $request->fecha_evento,
                'fecha_hasta' => $request->fecha_hasta,
                'contenido' => $request->contenido,
                'imagen' => $filename,
                'usuario_id' => Auth::user()->id
            ]);
            $clientes = Usuario::role('Cliente')->get();
            Mail::to($clientes)->queue(new EventoMailable($evento));
            DB::commit();
            return redirect()->route('evento.show', $evento)->with('alert', ['type' => 'success']);
        } catch (Exception $e) {
            DB::rollBack();
            if ($e->getMessage() != "") {
                throw $e;
                return back()->with('alert', ['type' => 'error'])->withInput($request->except('imagen'));
            } else {
                return back()->with('alert', ['type' => 'error'])->withInput($request->except('imagen'));
            }
        }
    }
    public function update(Request $request, Evento $evento)
    {
        try {
            $this->validate($request, [
                'fecha_desde' => "required|date",
                'fecha_hasta' => "required|date|after_or_equal:fecha_desde",
                'titulo' => "required|string",
                'fecha_evento' => "required|date|before_or_equal:fecha_hasta",
                'imagen' => "image:jpg,jpeg,png,bmp",
                'contenido' => "required|string"
            ]);
            $filename = null;
            if ($request->imagen) {
                $folderPath = public_path('media/actividades/');
                if ($evento->imagen) {
                    $filename = $folderPath . $evento->imagen;
                    if (file_exists($filename)) {
                        unlink($filename);
                    }
                }
                $imagen = $request->file('imagen');
                $filename = Str::slug($request->titulo) . '_' . date('Ymd_His') . '.' . $imagen->guessExtension();
                $imagen->move($folderPath, $filename);
                $evento->update([
                    'imagen' => $filename
                ]);
            }
            $evento->update([
                'titulo' => $request->titulo,
                'fecha_desde' => $request->fecha_desde,
                'fecha_evento' => $request->fecha_evento,
                'fecha_hasta' => $request->fecha_hasta,
                'contenido' => $request->contenido
            ]);
            return redirect()->route('evento.show', $evento)->with('alert', ['type' => 'success']);
        } catch (Exception $e) {
            if ($e->getMessage() != "") {
                throw $e;
                return back()->with('alert', ['type' => 'error'])->withInput($request->all());
            } else {
                return back()->with('alert', ['type' => 'error'])->withInput($request->all());
            }
        }
    }
    public function destroy(Evento $evento)
    {
        if ($evento->imagen) {
            $folderPath = public_path('media/actividades/');
            $filename = $folderPath . $evento->imagen;
            if (file_exists($filename)) {
                unlink($filename);
            }
        }
        $evento->delete();
        return redirect()->route('evento.index');
    }
}
