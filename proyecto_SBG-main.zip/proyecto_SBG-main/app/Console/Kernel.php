<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use App\Http\Controllers\HistorialPagoController;
use App\Http\Controllers\PayUController;
use App\Http\Controllers\UsuarioController;
use App\Models\PseBanco;
use App\Models\Usuario;

class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     */
    protected function schedule(Schedule $schedule): void
    {
        // $schedule->command('inspire')->hourly();
        $schedule->call(function () {
            $controlador = new HistorialPagoController();
            $controlador->store();
        })->name("Generar_Nuevo_Cobros")->daily()->withoutOverlapping()->onOneServer();
        $schedule->call(function () {
            $controlador = new HistorialPagoController();
            $controlador->reportarVencidos();
        })->name("Reportar_Pagos_Vencidos")->daily()->withoutOverlapping()->onOneServer();
        $schedule->call(function () {
            $controlador = new HistorialPagoController();
            $controlador->mostrarCobroCliente();
        })->name("Mostrar_Cobro_Clientes")->daily()->withoutOverlapping()->onOneServer();
        $schedule->call(function () {
            $controlador = new UsuarioController();
            $controlador->reportarCuentas();
        })->name("Programador_Cuentas_Usuarios")->daily()->withoutOverlapping()->onOneServer();

        $schedule->call(function () {
            $controlador = new PayUController();
            $controlador->bancosAfiliadosPSE();
        })->name("Consultar_Bancos_PSE")->daily()->withoutOverlapping()->onOneServer();
    }
    protected function commands(): void
    {
        $this->load(__DIR__ . '/Commands');

        require base_path('routes/console.php');
    }
}
