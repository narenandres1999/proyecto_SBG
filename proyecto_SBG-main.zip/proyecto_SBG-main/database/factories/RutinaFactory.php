<?php

namespace Database\Factories;

use App\Models\Enfoque;
use App\Models\Usuario;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Rutina>
 */
class RutinaFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $enfoques = Enfoque::all()->modelKeys();
        $usuarios = Usuario::all()->modelKeys();
        return [
            'dificultad' => $this->faker->randomElement(['Fácil', 'Medio', 'Difícil']),
            'enfoque_id' => $this->faker->randomElement($enfoques),
            'start_date' => $this->faker->dateTimeBetween('-2 week', 'now'),
            'end_date' => $this->faker->dateTimeBetween('-2 week', '+1 week'),
            'usuario_id' => $this->faker->randomElement($usuarios)
        ];
    }
}
