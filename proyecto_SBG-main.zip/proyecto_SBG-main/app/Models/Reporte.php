<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\Ingresos_diario;
use App\Models\Historiale;
use App\Models\Historial_pago;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Reporte extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $guarded = [];
    // Definición de los métodos de relaciones

    // Me muestra los datos del ingreso (si lo tiene )
    public function ingresosDiarios(): HasMany
    {
        return $this->hasMany(Ingresos_diario::class);
    }
    // Muestra los datos del historial del entrenador (si lo tiene )
    public function historiales(): HasMany
    {
        return $this->hasMany(historiale::class);
    }
    // Muestra los datos del historial de pago de una membresia (si lo tiene)
    public function historialPagos(): HasMany
    {
        return $this->hasMany(Historial_pago::class);
    }

}
