<?php

namespace App\Http\Controllers;

use App\Jobs\ProccessMail;
use App\Mail\MembresiaMailable;
use Illuminate\Http\Request;
use App\Models\Historial_pago;
use App\Models\Membresia;
use App\Models\Usuario;
use App\Models\Reporte;
use Carbon\Carbon;
use Exception;
use GuzzleHttp\Promise\Promise;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class HistorialPagoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $r, Usuario $usuario = null)
    {
        $search = $r->search;
        if (!$usuario) {
            $pagos = Historial_pago::withTrashed()->where(function (Builder $query) use ($search) {
                $query->whereRelation('usuario', 'nombre', 'ilike', '%' . $search . '%')
                    ->orwhereRelation('usuario', 'apellidos', 'ilike', '%' . $search . '%')
                    ->orwhere('estado', 'ilike', '%' . $search . '%')->get();
            })->where(function (Builder $query) {
                $query->where('estado', 'Pendiente')
                    ->orwhere('estado', 'Vencido')->get();
            })
                ->orderByDesc('updated_at')
                ->paginate(5);
            return view('payments_history.index', compact('pagos', 'search'));
        } else {
            $pagos = Historial_pago::where('usuario_id', $usuario->id)->get();
        }
        return $pagos;
    }
    public function show(string $pago)
    {
        $mostrar = Historial_pago::find($pago);
        return $mostrar;
    }

    public function edit(Historial_pago $pago)
    {
        return view('payments_history.show', compact('pago'));
    }

    public function update(Request $request, String $pago)
    {
        $update = Historial_pago::withTrashed()->find($pago);
        // Busca reporte con el mes y año actual
        $reporte = Reporte::whereMonth('fecha_reporte', now()->month)->whereYear('fecha_reporte', now()->year)->get()->first();
        // de no existir uno lo crea
        if ($reporte == []) {
            $reporte = Reporte::create([
                'fecha_reporte' => now()
            ]);
        }
        if ($request->estado == "Pagado" && $update->estado != 'Pagado') {
            if (!($request->estado == $update->estado)) {
                $reporte->update([
                    'ganancia' => $reporte->ganancia + $update->valor
                ]);
            }
            $update->update([
                'modalidad' => $request->modalidad,
                'estado' => $request->estado,
                'fecha_pago' => now(),
                'reporte_id' => $reporte->id
            ]);
            $update->restore();
            return back()->with('alert', ['type' => 'info']);
        } else {
            if (!($request->estado == $update->estado)) {
                $reporte->update([
                    'ganancia' => $reporte->ganancia - $update->valor
                ]);
                $update->update([
                    'modalidad' => null,
                    'estado' => $request->estado,
                    'fecha_pago' => null,
                    'reporte_id' => null
                ]);
            }
            $update->update([
                'modalidad' => $request->modalidad
            ]);
            return back()->with('alert', ['type' => 'info']);
        }
        return back()->with('alert', ['type' => 'error']);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Historial_pago $pago)
    {
        $delete = Historial_pago::withTrashed()->find($pago->id);
        $delete_copia = $delete;
        $delete->forceDelete();
        $reporte = Reporte::find($delete_copia->reporte_id);
        if ($delete_copia->estado == "Pagado") {
            $reporte->update([
                'ganancia' => $reporte->ganancia - $delete_copia->valor
            ]);
        }
        return "Se ha eliminado con exito";
    }
    // Métodos para el programador de tareas
    public function store()
    {
        try {
            DB::beginTransaction();
            Usuario::whereDate('proxima_generacion', '<=', now())->chunkById(100, function (Collection $usuarios) {
                foreach ($usuarios as $usuario) {
                    if (!($usuario->membresia_id == null)) {
                        $pagos = $usuario->historialPagos()->where('estado', "Vencido")->get();
                        if (!($pagos->count()  >= 1)) {
                            $membresia_activa = $usuario->membresia;
                            $duracion_membresia = $membresia_activa->duracion_dias;
                            $valor_membresia = $membresia_activa->valor;
                            $proxima_generacion = Carbon::parse($usuario->proxima_generacion);
                            $fecha_limite = $proxima_generacion->addDays($duracion_membresia);
                            if (now()->monthName == $fecha_limite->monthName) {
                                $mes_factura = now()->monthName;
                            } else {
                                $mes_factura = now()->monthName . "-" . $fecha_limite->monthName;
                            }
                            $cobro_nuevo = Historial_pago::create([
                                'fecha_limite' => $fecha_limite,
                                'mes_factura' => $mes_factura,
                                'valor' => $valor_membresia,
                                'estado' => 'Pendiente',
                                'usuario_id' => $usuario->id,
                                'membresia_id' => $usuario->membresia_id
                            ]);
                            $cobro_nuevo->delete();
                            $usuario->update([
                                'proxima_generacion' => $fecha_limite->addDays(1)
                            ]);
                        }
                    }
                }
            });
            DB::commit();
        } catch (Exception $e) {
            DB::rollBack();
            return throw $e;
        }
    }
    // Debo modificar de menor manera estas consultas (El ciclo foreach se puede integrar en la consulta )
    // Como un update masivo desde la base de datos para no tener que recorrer colecciones
    public function reportarVencidos()
    {
        Historial_pago::withTrashed()->Where('estado', 'Pendiente')->WhereDate('fecha_limite', '<', now())->update(['estado' => 'Vencido']);
    }
    public function mostrarCobroCliente()
    {
        $segundos = 0;
        Historial_pago::onlyTrashed()->chunkById(100, function (Collection $pagos) use ($segundos) {
            foreach ($pagos as $pago) {
                $usuario = $pago->usuario;
                if (!($usuario->membresia_id == null)) {
                    $membresia_activa = $usuario->membresia;
                    $fecha_limite = Carbon::parse($pago->fecha_limite);
                    $duracion_membresia = $membresia_activa->duracion_dias;
                    $dias_restantes = $fecha_limite->dayOfYear - now()->dayOfYear;

                    // Si la membresia es quincenal o inferior
                    // Cuando le queden 5 dias o menos hagalo visible para el cliente

                    if ($duracion_membresia <= 15 && $dias_restantes <= 5) {
                        $pago->restore();
                        $pago = $pago->fresh();
                        Mail::to($pago->usuario)->later($segundos, new MembresiaMailable($pago));
                        $segundos += 10;
                    }
                    // Si la membresia dura entre 15 a 60 dias
                    // Cuando le queden 10 dias o menos hagalo visible para el cliente
                    if (15 < $duracion_membresia && $duracion_membresia <= 60  && $dias_restantes <= 10) {
                        $pago->restore();
                        $pago = $pago->fresh();
                        Mail::to($pago->usuario)->later($segundos, new MembresiaMailable($pago));
                        $segundos += 10;
                    }
                    // Si la membresia dura más de 60 dias entonces
                    // Cuando le queden 15 dias o menos hagalo visible para el cliente
                    if ($duracion_membresia > 60 && $dias_restantes <= 15) {
                        $pago->restore();
                        $pago = $pago->fresh();
                        Mail::to($pago->usuario)->later($segundos, new MembresiaMailable($pago));
                        $segundos += 10;
                    }
                }
            }
        });
    }
}
