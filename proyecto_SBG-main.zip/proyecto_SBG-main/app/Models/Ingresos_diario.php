<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\Producto;
use Illuminate\Database\Eloquent\SoftDeletes;

class Ingresos_diario extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $guarded = [];
    protected $dateFormat = 'Y/m/d H:i:s';
    // Accede a la informacion del producto al que esta ligado
    public function producto(): BelongsTo
    {
        return $this->belongsTo(Producto::class)->withDefault();
    }
}
