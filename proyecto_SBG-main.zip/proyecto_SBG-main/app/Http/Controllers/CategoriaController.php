<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Categoria;
use Exception;

class CategoriaController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->search;
        $tipo = $request->tipo;
        $categorias = Categoria::where('nombre', 'ilike', '%' . $search . '%')
            ->where('tipo', 'ilike', '%' . $tipo . '%')
            ->orderBy('nombre')
            ->paginate(10);
        $categorias_ejercicio = Categoria::where('tipo','ejercicio')->count();
        $categorias_producto = Categoria::where('tipo','producto')->count();
        $categorias_ingresos = Categoria::where('tipo','ingresos_diarios')->count();
        $categorias_todos = Categoria::count();
        return view('category.index', compact('categorias','categorias_ejercicio','categorias_producto','categorias_todos','categorias_ingresos','tipo'));
    }
    public function update(Request $request, Categoria $categoria)
    {
        try {
            $this->validate($request,[
                'nombre' => 'required',
                'tipo' => 'tipo'
            ]);
            $categoria->update($request->all());
            return back()->with('alert', ['type' => 'info']);
        } catch (Exception $e) {
            throw $e;
            return back()->with('alert', ['type' => 'error']);
        }
    }

    public function destroy(Categoria $categoria)
    {
        $categoria->delete();
    }
}
