<?php

namespace App\Http\Controllers;

use App\Models\Asistencia;
use App\Models\Historiale;
use App\Models\Reporte;
use App\Models\Usuario;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HistorialeController extends Controller
{
    public function index(Request $request)
    {
        $pagos = Historiale::whereRelation('usuario', 'nombre', 'ilike', '%' . $request->search . '%')
                    ->orwhereRelation('usuario', 'apellidos', 'ilike', '%' . $request->search . '%')
                    ->orderByDesc('fecha_pago')
                    ->paginate(5);
        $entrenadores = Usuario::role('Entrenador')->orderBy('apellidos')->get();
        return view('trainers.payments_history.index',compact('pagos','entrenadores'));
    }
    public function create()
    {
        $entrenadores = Usuario::role('Entrenador')->orderBy('apellidos')->get();
        return view('trainers.payments_history.create', compact('entrenadores'));
    }
    public function store(Request $request)
    {
        try {
            DB::beginTransaction();
            $this->validate($request, [
                'usuario_id' => 'required',
                'desde' => 'required|date',
                'hasta' => 'required|date|after:desde',
                'valor_hora' => 'required|numeric',
                'horas_laburadas' => 'required|numeric',
                'valor_total' => 'required|numeric'
            ], [], [
                'usuario_id' => 'entrenador',
            ]);
            $reporte = Reporte::whereMonth('fecha_reporte', now()->month)->whereYear('fecha_reporte', now()->year)->get()->first();
            // de no existir uno lo crea
            if ($reporte == []) {
                $reporte = Reporte::create([
                    'fecha_reporte' => now()
                ]);
            }
            $historial = Historiale::create([
                'fecha_pago' => now(),
                'valor_hora' => $request->valor_hora,
                'fecha_desde' => $request->desde,
                'fecha_hasta' => $request->hasta,
                'total_horas' => $request->horas_laburadas,
                'valor_pagado' => $request->valor_total,
                'reporte_id' => $reporte->id,
                'usuario_id' => $request->usuario_id
            ]);
            $reporte->update([
                'ganancia' => $reporte->ganancia - $request->valor_total
            ]);
            // Asistencia::where('usuario_id', $request->usuario_id)
            // ->whereDate('start_date', '>=', $request->desde)
            // ->whereDate('start_date', '<=', $request->hasta)
            // ->delete();
            DB::commit();
            return redirect()->route('historial.index')->with('alert', ['type' => 'success']);
        } catch (Exception $e) {
            DB::rollBack();
            if ($e->getMessage() != "") {
                back()->with('alert', ['type' => 'error']);
                throw $e;
            }
            return back()->with('alert', ['type' => 'error']);
        }
    }
    public function destroy(Historiale $historial)
    {
        $reporte = $historial->reporte;
        $reporte->update([
            'ganancia' => $reporte->ganancia + $historial->valor_pagado
        ]);
        $historial->delete();
    }
}
