<?php

namespace Database\Factories;

use App\Models\Usuario;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Antropometrica>
 */
class AntropometricaFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        // Añadiendo a main
        $keys = Usuario::all()->modelKeys();
        return [
            'fecha' => now(),
            'estatura' => $estatura = $this->faker->randomFloat(2,1,2),
            'peso' => $peso = $this->faker->randomFloat(1,50,150),
            'busto-torax' => $this->faker->randomFloat(1,10,40),
            'hombro' => $this->faker->randomFloat(1,10,40),
            'brazo' => $this->faker->randomFloat(1,10,40),
            'cintura' => $this->faker->randomFloat(1,10,40),
            'cadera' => $this->faker->randomFloat(1,10,40),
            'pierna' => $this->faker->randomFloat(1,10,40),
            'IMC' => ($peso / pow($estatura,2)),
            'usuario_id' => $this->faker->randomElement($keys)
        ];
    }
}
