<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Enfoque>
 */
class EnfoqueFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $data  = [
            "antebrazo",
            "banco_plano",
            "barra_libre_sm",
            "barras_libres",
            "barras",
            "biceps",
            "bicicleta",
            "brazo_completo",
            "brazo",
            "caminadora",
            "cronometro",
            "cuello",
            "cuerpo_completo",
            "elevacion_mancuerna",
            "espalda",
            "estiramiento",
            "grasa_abdominal",
            "hombros",
            "jalon_pecho",
            "mancuerna_lg",
            "mancuerna",
            "mancuernas_sm",
            "mancuernas",
            "pecho",
            "peck_deck",
            "pesas",
            "peso",
            "pierna_1",
            "pierna_2",
            "soga",
            "tarjeta_control",
            "trampolin",
            "triceps",
        ];
        $selected = $this->faker->randomElement($data);
        return [
            'titulo' => $selected,
            'avatar' => $selected . '.png',
        ];
    }
}
