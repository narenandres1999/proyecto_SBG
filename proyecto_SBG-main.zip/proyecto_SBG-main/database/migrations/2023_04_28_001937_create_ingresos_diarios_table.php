<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ingresos_diarios', function (Blueprint $table) {
            $table->id();
            $table->string('concepto');
            $table->integer('cantidad');
            $table->integer('valor')->default(0);// Este campo se rellenara con el de productos
            $table->integer('salida')->default(0);
            $table->integer('valorTotal');
            $table->softDeletes();
            $table->timestamps();
            // Aqui van las relaciones
            $table->foreignId('reporte_id')->nullOnDelete()->constrained();
            $table->string('producto_sku')->nullOnDelete()->nullable();
            $table->foreign('producto_sku')->references('sku')->on('productos');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ingresos_diarios');
    }
};
