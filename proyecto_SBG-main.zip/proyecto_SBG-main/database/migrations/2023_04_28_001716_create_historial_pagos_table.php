<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('historial_pagos', function (Blueprint $table) {
            $table->id();
            $table->date('fecha_limite');
            $table->string('mes_factura');
            $table->integer('valor');
            $table->string('modalidad')->nullable();
            $table->string('estado');
            $table->date('fecha_pago')->nullable();
            $table->timestamps();
            $table->softDeletes();
            // Relaciones
            $table->foreignId('membresia_id')->constrained();
            $table->foreignId('reporte_id')->nullOnDelete()->nullable()->constrained();
            $table->uuid('usuario_id')->nullOnDelete();
            $table->foreign('usuario_id')->references('id')->on('usuarios');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('historial_pagos');
    }
};
