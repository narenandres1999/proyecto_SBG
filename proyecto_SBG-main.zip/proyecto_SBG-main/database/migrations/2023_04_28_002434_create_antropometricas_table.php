<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('antropometricas', function (Blueprint $table) {
            $table->id();
            $table->date('fecha');
            $table->double('estatura',10,2);
            $table->double('peso',10,1);
            $table->double('busto-torax',10,1);
            $table->double('hombro',10,1);
            $table->double('brazo',10,1);
            $table->double('cintura',10,1);
            $table->double('cadera',10,1);
            $table->double('pierna',10,1);
            $table->double('IMC',10,1);
            $table->softDeletes();
            $table->timestamps();
            // Relaciones
            $table->uuid('usuario_id')->nullOnDelete();
            $table->foreign('usuario_id')->references('id')->on('usuarios');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('antropometricas');
    }
};
