<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ejercicio_enfoque', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            $table->integer('repeticiones');
            $table->integer('series');
            $table->integer('rutina_id');
            // Relaciones
            $table->foreignId('ejercicio_id')->cascadeOnDelete()->constrained();
            $table->foreignId('enfoque_id')->cascadeOnDelete()->constrained();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ejercicio_enfoque');
    }
};
