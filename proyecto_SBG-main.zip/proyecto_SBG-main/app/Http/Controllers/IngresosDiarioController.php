<?php

namespace App\Http\Controllers;

use App\Models\Producto;
use Illuminate\Http\Request;
use App\Models\Ingresos_diario;
use App\Http\Resources\IngresoResource;
use App\Models\Categoria;
use Illuminate\Database\Eloquent\Builder;
use App\Models\Reporte;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\DB;

use function PHPUnit\Framework\isEmpty;
use function PHPUnit\Framework\isNull;

class IngresosDiarioController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public $fecha;
    public $search;

    public function index(Request $r)
    {
        $fecha = new Carbon($r->fecha); // Obtener la fecha del formulario
        $search = $r->search; // Obtener el término de búsqueda del formulario

        $ingresos = Ingresos_diario::where(function (Builder $query) use ($fecha) {
            $query->whereMonth('created_at', $fecha->month)
                ->whereYear('created_at', $fecha->year);
        })
            ->where(function (Builder $query) use ($search) {
                $query->where('id', 'ilike', '%' . $search . '%')
                    ->orWhere('concepto', 'ilike', '%' . $search . '%')
                    ->orWhereRelation('producto', 'nombre', 'ilike', '%' . $search . '%');
            })->orderByDesc('created_at')
            ->paginate(5);

        return view('daily_income.index', compact('ingresos', 'fecha', 'search'));
    }


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('daily_income.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            DB::beginTransaction();
            $this->validate($request, [
                'concepto' => 'required|string|max: 50',
                'cantidad' => 'required|integer|min: 1',
                'valor' => 'required|integer',
                'valorTotal' => 'required|integer',
                'salida' => 'required|integer',
                'producto_sku',
            ]);
            // Busca reporte con el mes y año actual
            $reporte = Reporte::whereMonth('fecha_reporte', now()->month)->whereYear('fecha_reporte', now()->year)->get()->first();
            // de no existir uno lo crea
            if ($reporte == []) {
                $reporte = Reporte::create([
                    'fecha_reporte' => now()
                ]);
            }
            $request['reporte_id'] = $reporte->id;
            $formulario = $request->all();
            // Crea un nuevo ingreso diario
            if($request->concepto == 'otro'){
                $request['concepto'] = $request->nuevo_concepto;
            }
            $ingreso_diario = Ingresos_diario::create($request->except('nuevo_concepto','guardar'));

            if ($request->guardar == 'aceptado'){
                Categoria::create(['tipo' => 'ingresos_diarios','nombre'=> $request->nuevo_concepto]);
            }
            // Aumenta las ganancias en el reporte
            $reporte->update([
                "ganancia" => $reporte->ganancia + $request->valorTotal
            ]);
            // Llegando el caso que sea un producto lo busca y actualiza su stock
            if (strtolower($formulario['concepto']) === "producto") {
                $producto = Producto::find($formulario['producto_sku']);
                if (($producto->disponible - $request->cantidad) < 0) {
                    back()->withErrors(['cantidad' => 'No hay suficiente existencias del producto que deseas']);
                    throw new Exception();
                }
                $producto->update([
                    "disponible" => $producto->disponible - $request->cantidad
                ]);
            }
            DB::commit();
            return back()->with('alert', ['type' => 'success']);
        } catch (Exception $e) {
            if ($e->getMessage() != "") {
                throw $e;
            }
            DB::rollBack();
            return back()->with('alert', ['type' => 'error']);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $ingreso)
    {

        return new IngresoResource(Ingresos_diario::find($ingreso));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Ingresos_diario $ingreso)
    {
        return view('daily_income.edit', compact('ingreso'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Ingresos_diario $ingreso)
    {
        $this->validate($request, [
            'concepto' => 'required|string|max: 50',
            'cantidad' => 'required|integer|min: 1',
            'valor' => 'required|integer',
            'salida' => 'required|integer',
            'valorTotal' => 'required|integer',
            'producto_sku',
        ]);
        $reporte = Reporte::find($ingreso->reporte_id);
        $reporte->update([
            "ganancia" => $reporte->ganancia - $ingreso->valorTotal
        ]);
        if ($ingreso->producto_sku) {
            $producto = Producto::find($ingreso->producto_sku);

            $producto->update([
                'disponible' => $producto->disponible + $ingreso->cantidad,
            ]);
        }
        if ($request->producto_sku) {
            $producto = Producto::find($request->producto_sku);
            $producto->update([
                'disponible' => $producto->disponible - $request->cantidad,
            ]);
        }
        if($request->concepto == 'otro'){
            $request['concepto'] = $request->nuevo_concepto;
        }
        $ingreso->update($request->except(['producto','nuevo_concepto','guardar']));
        $reporte->update([
            "ganancia" => $reporte->ganancia + $request->valorTotal
        ]);
        if ($request->guardar == 'aceptado'){
            Categoria::create(['tipo' => 'ingresos_diarios','nombre'=> $request->nuevo_concepto]);
        }
        return back()->with('alert', ['type' => 'info']);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Ingresos_diario $ingreso)
    {
        $reporte = Reporte::find($ingreso->reporte_id);
        if (!($ingreso->producto_sku == null)) {

            $producto = Producto::find($ingreso->producto_sku);
            $producto->update([
                'disponible' => $producto->disponible + $ingreso->cantidad,
            ]);
        }
        $reporte->update([
            "ganancia" => $reporte->ganancia - $ingreso->valorTotal
        ]);
        $ingreso->forceDelete();
        return  back()->with('alert', ['type' => 'success']);
    }
}
