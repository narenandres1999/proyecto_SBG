<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use App\Models\Usuario;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\Hash;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();

        Role::firstOrCreate(['name' => 'Admin', 'guard_name' => 'web']);
        Role::firstOrCreate(['name' => 'Entrenador', 'guard_name' => 'web']);
        Role::firstOrCreate(['name' => 'Cliente', 'guard_name' => 'web']);
        // Usuarios de prueba


        // Permisos para UsuarioController
        Permission::firstOrCreate(['name' => 'usuarios.index'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'usuarios.create'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'usuarios.store'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'usuarios.edit'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'usuarios.show'])->syncRoles(['Admin', 'Entrenador', 'Cliente']);
        Permission::firstOrCreate(['name' => 'usuarios.update'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'usuarios.updatePresentacion'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'usuarios.bannedList'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'usuarios.destroy'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'usuarios.restore'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'usuarios.todos'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'usuarios.clientes'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'usuarios.entrenadores'])->syncRoles(['Admin', 'Cliente', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'usuarios.administradores'])->syncRoles(['Admin']);
        //Permisos para Producto Controller
        Permission::firstOrCreate(['name' => 'productos.index'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'productos.create'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'productos.store'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'productos.show'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'productos.edit'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'productos.update'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'productos.destroy'])->syncRoles(['Admin']);

        //Permisos para IngresosDiarioController
        Permission::firstOrCreate(['name' => 'ingresos.index'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'ingresos.create'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'ingresos.store'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'ingresos.show'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'ingresos.edit'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'ingresos.update'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'ingresos.destroy'])->syncRoles(['Admin']);


        //Permisos para AntropometricaController
        Permission::firstOrCreate(['name' => 'antropometricas.index'])->syncRoles(['Admin', 'Entrenador', 'Cliente']);
        Permission::firstOrCreate(['name' => 'antropometricas.create'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'antropometricas.store'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'antropometricas.show'])->syncRoles(['Admin', 'Entrenador', 'Cliente']);
        Permission::firstOrCreate(['name' => 'antropometricas.edit'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'antropometricas.update'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'antropometricas.destroy'])->syncRoles(['Admin']);

        //Permisos para ObservacioneController
        Permission::firstOrCreate(['name' => 'observaciones.index'])->syncRoles(['Admin', 'Entrenador', 'Cliente']);
        Permission::firstOrCreate(['name' => 'observaciones.create'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'observaciones.store'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'observaciones.show'])->syncRoles(['Admin', 'Entrenador', 'Cliente']);
        Permission::firstOrCreate(['name' => 'observaciones.edit'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'observaciones.update'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'observaciones.destroy'])->syncRoles(['Admin']);

        //Permisos para HistorialPagoController
        Permission::firstOrCreate(['name' => 'pagos.index'])->syncRoles(['Admin', 'Cliente']);
        Permission::firstOrCreate(['name' => 'pagos.show'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'pagos.edit'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'pagos.update'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'pagos.destroy'])->syncRoles(['Admin']);

        //Permisos para PerfilController
        Permission::firstOrCreate(['name' => 'perfil.index'])->syncRoles(['Admin', 'Entrenador', 'Cliente']);
        Permission::firstOrCreate(['name' => 'perfil.update'])->syncRoles(['Admin', 'Entrenador', 'Cliente']);
        Permission::firstOrCreate(['name' => 'perfil.updatePassword'])->syncRoles(['Admin', 'Entrenador', 'Cliente']);
        Permission::firstOrCreate(['name' => 'perfil.updatePhoto'])->syncRoles(['Admin', 'Entrenador', 'Cliente']);
        Permission::firstOrCreate(['name' => 'perfil.deletePhoto'])->syncRoles(['Admin', 'Entrenador', 'Cliente']);

        // Permisos para TituloAcademicoController
        Permission::firstOrCreate(['name' => 'titulo.store'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'titulo.update'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'titulo.destroy'])->syncRoles(['Admin']);

        // Permisos para CategoriaController
        Permission::firstOrCreate(['name' => 'categoria.index'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'categoria.store'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'categoria.edit'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'categoria.update'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'categoria.destroy'])->syncRoles(['Admin', 'Entrenador']);

        //Permisos para MembresiaController
        Permission::firstOrCreate(['name' => 'membresia.index'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'membresia.create'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'membresia.shopping'])->syncRoles(['Cliente']);
        Permission::firstOrCreate(['name' => 'membresia.edit'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'membresia.store'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'membresia.update'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'membresia.destroy'])->syncRoles(['Admin']);

        // Permisos para TituloAcademicoController
        Permission::firstOrCreate(['name' => 'titulo.store'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'titulo.update'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'titulo.destroy'])->syncRoles(['Admin']);

        // Permisos para EnfoqueController
        Permission::firstOrCreate(['name' => 'enfoque.index'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'enfoque.create'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'enfoque.store'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'enfoque.edit'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'enfoque.update'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'enfoque.destroy'])->syncRoles(['Admin', 'Entrenador']);
        // Permisos para EjercicioController
        Permission::firstOrCreate(['name' => 'ejercicio.index'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'ejercicio.create'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'ejercicio.store'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'ejercicio.edit'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'ejercicio.update'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'ejercicio.destroy'])->syncRoles(['Admin', 'Entrenador']);

        // Permisos para RutinaController
        Permission::firstOrCreate(['name' => 'rutina.index'])->syncRoles(['Admin', 'Entrenador', 'Cliente']);
        Permission::firstOrCreate(['name' => 'rutina.create'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'rutina.store'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'rutina.edit'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'rutina.list'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'rutina.update'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'rutina.destroy'])->syncRoles(['Admin', 'Entrenador']);

        //Permisos para ReporteController
        Permission::firstOrCreate(['name' => 'reporte.index'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'reporte.show'])->syncRoles(['Admin']);

        //Permisos para ForoController
        Permission::firstOrCreate(['name' => 'foro.index'])->syncRoles(['Admin', 'Entrenador', 'Cliente']);
        Permission::firstOrCreate(['name' => 'foro.create'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'foro.store'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'foro.edit'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'foro.show'])->syncRoles(['Admin', 'Entrenador', 'Cliente']);
        Permission::firstOrCreate(['name' => 'foro.update'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'foro.destroy'])->syncRoles(['Admin', 'Entrenador']);

        //Permisos para AsistenciaController
        Permission::firstOrCreate(['name' => 'asistencia.index'])->syncRoles(['Admin']);
        // Permission::firstOrCreate(['name' => 'asistencia.create'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'asistencia.store'])->syncRoles(['Admin']);
        // Permission::firstOrCreate(['name' => 'asistencia.edit'])->syncRoles(['Admin']);
        // Permission::firstOrCreate(['name' => 'asistencia.show'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'asistencia.update'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'asistencia.destroy'])->syncRoles(['Admin']);
        //Permisos para HistorialeController
        Permission::firstOrCreate(['name' => 'historial.index'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'historial.create'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'historial.store'])->syncRoles(['Admin']);
        // Permission::firstOrCreate(['name' => 'historial.edit'])->syncRoles(['Admin']);
        // Permission::firstOrCreate(['name' => 'historial.show'])->syncRoles(['Admin']);
        // Permission::firstOrCreate(['name' => 'historial.update'])->syncRoles(['Admin']);
        Permission::firstOrCreate(['name' => 'historial.destroy'])->syncRoles(['Admin']);
        // Permisos para EventoController
        Permission::firstOrCreate(['name' => 'evento.index'])->syncRoles(['Admin', 'Entrenador', 'Cliente']);
        Permission::firstOrCreate(['name' => 'evento.create'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'evento.store'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'evento.edit'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'evento.show'])->syncRoles(['Admin', 'Entrenador', 'Cliente']);
        Permission::firstOrCreate(['name' => 'evento.update'])->syncRoles(['Admin', 'Entrenador']);
        Permission::firstOrCreate(['name' => 'evento.destroy'])->syncRoles(['Admin', 'Entrenador']);
    }
}
