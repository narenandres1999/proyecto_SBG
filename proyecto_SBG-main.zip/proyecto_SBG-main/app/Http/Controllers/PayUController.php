<?php

namespace App\Http\Controllers;

use App\Models\Historial_pago;
use App\Models\Membresia;
use App\Models\PseBanco;
use App\Models\Reporte;
use App\Models\TypeIdentification;
use App\Models\Usuario;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Validation\ValidationException;
use Monolog\Formatter\JsonFormatter;

class PayUController extends Controller
{
    public array $headers = [
        'Content-Type' => 'application/json',
        'Accept' => 'application/json'
    ];
    // Este método irá asignado a un programador de tareas que se ejecutará una vez por día
    // Almacenando la información de los bancos afiliados a pse y para evitar siempre consultar a la api
    public function bancosAfiliadosPSE()
    {
        $response = Http::withHeaders($this->headers)->post(env('PAYU_BASE_URL') . 'payments-api/4.0/service.cgi', [
            'language' => 'es',
            'command' => 'GET_BANKS_LIST',
            'merchant' => [
                'apiLogin' => env('PAYU_SECRET'),
                'apiKey' => env('PAYU_KEY')
            ],
            'test' => true,
            'bankListInformation' => [
                'paymentMethod' => 'PSE',
                'paymentCountry' => 'CO'
            ]
        ]);
        foreach ($response->json()['banks'] as $banco) {
            PseBanco::firstOrCreate($banco);
        }
    }

    public function comprarMembresia(Membresia $membresia)
    {
        $usuario = Auth::user();
        $bancos = PseBanco::all();
        $deviceSessionId = md5(session_id() . microtime());
        $action = "compra_membresia_primera_vez";
        $tipos_documentos = TypeIdentification::all();
        return view('checkout.index', compact('bancos', 'membresia', 'usuario', 'deviceSessionId', 'action','tipos_documentos'));
    }
    public function pagarPendiente(Historial_pago $pago)
    {
        $usuario = Auth::user();
        $bancos = PseBanco::all();
        $deviceSessionId = md5(session_id() . microtime());
        $action = "cliente_regular";
        $tipos_documentos = TypeIdentification::all();
        return view('checkout.index', compact('bancos', 'pago', 'usuario', 'deviceSessionId', 'action','tipos_documentos'));
    }
    public function procesoPago(Request $request)
    {
        try {
            if ($request->FINANCIAL_INSTITUTION_CODE == 0) {
                back()->withErrors(['FINANCIAL_INSTITUTION_CODE' => 'Seleccione un banco'])->withInput($request->all());
                throw new Exception("");
            }
            $this->validate($request, [
                'USER_TYPE' => 'required',
                'PSE_REFERENCE2' => 'required',
                'PSE_REFERENCE3' => 'required',
                'firstname' => 'required',
                'lastname' => 'required',
                'phone' => 'required'
            ], [
                'USER_TYPE.required' => 'Seleccione el tipo de persona',
                'PSE_REFERENCE2.required' => 'Seleccione el tipo de documento',
                'PSE_REFERENCE3.required' => 'Ingrese el número de identificación'
            ], [
                'firstname' => 'nombres',
                'lastname' => 'apellidos',
                'phone' => 'telefono'
            ]);
            $user = Auth::user();
            // if ($user->membresia_id) {
            //     return redirect('/dashboard')->with('alert', [
            //         'type' => 'custom',
            //         'title' => '¡Ya has adquirido una membresía!',
            //         'message' => 'Ya tienes pago una membresía',
            //         'icon' => 'info'
            //     ]);
            // }
            $referenceCode = $request->referenceCode;
            $responseUrl = $request->responseUrl;
            $currency = 'COP';
            $signature = md5(env('PAYU_KEY') . '~' . env('PAYU_MERCHANT_ID') . '~' . $referenceCode . '~' . $request->valor_pagar . '~' . $currency);
            $data = [
                "language" => "es",
                "command" => "SUBMIT_TRANSACTION",
                "merchant" => [
                    "apiKey" => env('PAYU_KEY'),
                    "apiLogin" => env('PAYU_SECRET')
                ],
                "transaction" => [
                    "order" => [
                        "accountId" => env('PAYU_ACCOUNT_ID'),
                        "referenceCode" => $referenceCode,
                        "description" => "Compra de membresía",
                        "language" => "es",
                        "signature" => $signature,
                        "additionalValues" => [
                            "TX_VALUE" => [
                                "value" => intval($request->valor_pagar),
                                "currency" => "COP"
                            ]
                        ],
                        "buyer" => [
                            "merchantBuyerId" => $user->id,
                            "fullName" => $user->nombre . ' ' . $user->apellidos,
                            "emailAddress" => $user->email,
                            "contactPhone" => $user->telefono,
                            "dniNumber" => $request->PSE_REFERENCE3,
                            "shippingAddress" => [
                                "street1" => "Calle 2 #4-45",
                                "city" => "Corregimiento El Placer",
                                "state" => "Valle del Cauca",
                                "country" => "CO",
                                "postalCode" => "000000",
                                "phone" => $user->telefono
                            ]
                        ],
                        "shippingAddress" => [
                            "street1" => "Cr 23 No. 53-50",
                            "street2" => "5555487",
                            "city" => "Corregimiento El Placer",
                            "state" => "Valle del Cauca",
                            "country" => "CO",
                            "postalCode" => "0000000",
                            "phone" => $user->telefono
                        ]
                    ],
                    "payer" => [
                        "merchantPayerId" => $user->id,
                        "fullName" => $user->nombre . ' ' . $user->apellidos,
                        "emailAddress" => $user->email,
                        "contactPhone" => $user->telefono,
                        "dniNumber" => $request->PSE_REFERENCE3,
                        "billingAddress" => [
                            "street1" => "Calle 2 #4-45",
                            "street2" => "125544",
                            "city" => "Palmira",
                            "state" => "Valle del Cauca",
                            "country" => "CO",
                            "postalCode" => "000000",
                            "phone" => $user->telefono
                        ]
                    ],
                    "extraParameters" => [
                        "RESPONSE_URL" => $responseUrl,
                        "PSE_REFERENCE1" => $request->ip(),
                        "FINANCIAL_INSTITUTION_CODE" => $request->FINANCIAL_INSTITUTION_CODE,
                        "USER_TYPE" => $request->USER_TYPE,
                        "PSE_REFERENCE2" => $request->PSE_REFERENCE2,
                        "PSE_REFERENCE3" => $request->PSE_REFERENCE3
                    ],
                    "type" => "AUTHORIZATION_AND_CAPTURE",
                    "paymentMethod" => "PSE",
                    "paymentCountry" => "CO",
                    "deviceSessionId" => $request->deviceSessionId,
                    "ipAddress" => $request->ip(),
                    "cookie" => $request->cookie()['XSRF-TOKEN'],
                    "userAgent" => $request->server('HTTP_USER_AGENT')
                ],
                "test" => true
            ];
            $response = Http::withHeaders($this->headers)->post(env('PAYU_BASE_URL') . 'payments-api/4.0/service.cgi', $data);
            return redirect($response->json()['transactionResponse']['extraParameters']['BANK_URL']);
        } catch (Exception $e) {
            if ($e->getMessage() != "") {
                back()->with('alert', ['type' => 'error']);
                throw $e;
            }
            return back()->with('alert', ['type' => 'error']);
        }
    }
    public function verificarPagoMembresia(Request $request)
    {
        try {
            $factura = $request->all();
            DB::beginTransaction();
            $referencia = explode('_', $request->referenceCode);
            $usuario_id = $referencia[2];
            $membresia_id = $referencia[3];
            $membresia = Membresia::find($membresia_id);
            $usuario = Usuario::find($usuario_id);
            if (($request->lapTransactionState === 'APPROVED') && !($usuario->membresia_id)) {
                $reporte = Reporte::whereMonth('fecha_reporte', now()->month)->whereYear('fecha_reporte', now()->year)->get()->first();
                if ($reporte == []) {
                    $reporte = Reporte::create([
                        'fecha_reporte' => now()
                    ]);
                }
                $reporte->update([
                    "ganancia" => $reporte->ganancia + $membresia->valor
                ]);
                $fecha_limite = now()->addDays($membresia->duracion_dias);
                if (now()->monthName == $fecha_limite->monthName) {
                    $mes_factura = now()->monthName;
                } else {
                    $mes_factura = now()->monthName . "-" . $fecha_limite->monthName;
                }
                Historial_pago::create([
                    'fecha_limite' => now(),
                    'mes_factura' => $mes_factura,
                    'valor' => $membresia->valor,
                    'estado' => 'Pagado',
                    'modalidad' => 'Digital',
                    'usuario_id' => $usuario_id,
                    'membresia_id' => $membresia_id,
                    'reporte_id' => $reporte->id
                ]);
                $usuario->update([
                    'proxima_generacion' => $fecha_limite->addDays(1),
                    'suscripcion_activa' => 1,
                    'membresia_id' => $membresia_id
                ]);
                DB::commit();
                return view('checkout.invoice', compact('factura'));
            } else {
                return view('checkout.invoice', compact('factura'));
            }
        } catch (Exception $e) {
            DB::rollBack();
            back()->with('alert', ['type' => 'error']);
            throw $e;
        }
        return $request->all();
    }
    public function verificarPagoPendiente(Request $request)
    {
        try {
            $factura = $request->all();
            DB::beginTransaction();
            if ($request->lapTransactionState === 'APPROVED') {
                $referencia = explode('_', $request->referenceCode);
                $usuario_id = $referencia[2];
                $pago_id = $referencia[3];
                $pago = Historial_pago::find($pago_id);

                $reporte = Reporte::whereMonth('fecha_reporte', now()->month)->whereYear('fecha_reporte', now()->year)->get()->first();
                // de no existir uno lo crea
                if ($reporte == []) {
                    $reporte = Reporte::create([
                        'fecha_reporte' => now()
                    ]);
                }
                $reporte->update([
                    'ganancia' => $reporte->ganancia + $pago->valor
                ]);
                $pago->update([
                    'modalidad' => 'Digital',
                    'estado' => 'Pagado',
                    'fecha_pago' => now(),
                    'reporte_id' => $reporte->id
                ]);
                DB::commit();
                return view('checkout.invoice', compact('factura'));
            } else {
                return view('checkout.invoice', compact('factura'));
            }
        } catch (Exception $e) {
            DB::rollBack();
            back()->with('alert', ['type' => 'error']);
            throw $e;
        }
    }
}
