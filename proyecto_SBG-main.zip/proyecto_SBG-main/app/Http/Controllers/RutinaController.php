<?php

namespace App\Http\Controllers;

use App\Http\Resources\RutinaResource;
use App\Models\Categoria;
use App\Models\Enfoque;
use Illuminate\Http\Request;
use App\Models\Rutina;
use App\Models\Usuario;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;

class RutinaController extends Controller
{
    public function list(Request $request)
    {
        $dificultad = $request->dificultad;
        $todos  = Rutina::all();
        $facil = $todos->where('dificultad', 'Fácil')->count();
        $medio = $todos->where('dificultad', 'Medio')->count();
        $dificil = $todos->where('dificultad', 'Difícil')->count();
        $todos = $todos->count();
        $conteo = compact('facil', 'medio', 'dificil', 'todos');
        $search = $request->search;
        $rutinas = Rutina::where(function (Builder $query) use ($dificultad) {
            $query->where('dificultad', 'ilike', '%' . $dificultad . '%')->get();
        })->where(function (Builder $query) use ($search) {
            $query->whereRelation('usuario', 'nombre', 'ilike', '%' . $search . '%')
                ->orWhereRelation('usuario', 'apellidos', 'ilike', '%' . $search . '%')
                ->orWhereRelation('enfoque', 'titulo', 'ilike', '%' . $search . '%')
                ->get();
        })->orderByDesc('created_at')->paginate(10);
        return view('routines.list', compact('search', 'rutinas', 'dificultad', 'conteo'));
    }
    public function create()
    {
        $categorias = Categoria::where('tipo', 'ejercicio')->has('ejercicios')->orderBy('nombre')->get();
        return view('routines.create', compact('categorias'));
    }
    public function edit(Rutina $rutina)
    {
        $categorias = Categoria::where('tipo', 'ejercicio')->has('ejercicios')->orderBy('nombre')->get();
        $ejercicios = $rutina->enfoque->ejercicios()->wherePivot('rutina_id', $rutina->id)->get();
        return view('routines.edit', compact('rutina', 'categorias', 'ejercicios'));
    }
    public function index(Request $request)
    {
        $entrenadores = Usuario::role('Entrenador')->get();
        $search = $request->search;
        $rutinas = Rutina::where(function (Builder $query) {
            $query->whereDate('start_date', '<=', now())->whereDate('end_date', '>=', now())->get();
        })->where(function (Builder $query) use ($search) {
            $query->where('dificultad', 'ilike', '%' . $search . '%')
                ->orwhereRelation('usuario', 'nombre', 'ilike', '%' . $search . '%')
                ->orwhereRelation('usuario', 'apellidos', 'ilike', '%' . $search . '%')->get();
        })
            ->orderBy('dificultad')
            ->paginate(10);
        $rutinas = RutinaResource::collection($rutinas);
        return view('routines.index', compact('rutinas', 'entrenadores'));
    }
    public function store(Request $request)
    {
        $this->validate($request, [
            'dificultad' => 'required',
            'enfoque_id' => 'required',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date'
        ], [], ['enfoque_id' => 'enfoque', 'start_date' => 'visible desde', 'end_date' => 'visible hasta']);
        if (!$request->ejercicios) {
            return back()->withErrors(['ejercicios' => 'Añada ejercicios a la rutina'])->withInput($request->all());
        }
        $enfoque = Enfoque::find($request->enfoque_id);
        $request['usuario_id'] = Auth::user()->id;
        $rutina = Rutina::create($request->only(
            'dificultad',
            'enfoque_id',
            'usuario_id',
            'start_date',
            'end_date'
        ));
        foreach ($request->ejercicios as $ejercicio) {
            $enfoque->ejercicios()->attach($ejercicio['id'], [
                'repeticiones' => $ejercicio['repeticiones'],
                'series' => $ejercicio['series'],
                'rutina_id' => $rutina->id
            ]);
            $ejercicios_agregados[] = $ejercicio;
        }
        return back()->with('alert', ['type' => 'success']);
    }
    public function update(Request $request, Rutina $rutina)
    {
        $this->validate($request, [
            'dificultad' => 'required',
            'enfoque_id' => 'required',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date'
        ], [], ['enfoque_id' => 'enfoque', 'start_date' => 'visible desde', 'end_date' => 'visible hasta']);
        if (!$request->ejercicios) {
            return back()->withErrors(['ejercicios' => 'Añada ejercicios a la rutina'])->withInput($request->all());
        }
        $rutina->update($request->only(
            'dificultad',
            'enfoque_id',
            'usuario_id',
            'start_date',
            'end_date'
        ));
        $rutina->refresh();
        $enfoque = Enfoque::find($request->enfoque_id);
        $enfoque->ejercicios()->wherePivot('rutina_id', $rutina->id)->detach();
        foreach ($request->ejercicios as $ejercicio) {
            $enfoque->ejercicios()->attach($ejercicio['id'], [
                'repeticiones' => $ejercicio['repeticiones'],
                'series' => $ejercicio['series'],
                'rutina_id' => $rutina->id
            ]);
            $ejercicios_agregados[] = $ejercicio;
        }
        return redirect()->route('rutina.list')->with('alert', ['type' => 'info']);
    }
    public function destroy(Rutina $rutina)
    {
        $rutina->delete();
    }
}
