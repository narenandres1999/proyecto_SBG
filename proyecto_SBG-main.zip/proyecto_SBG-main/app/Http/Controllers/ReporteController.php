<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Reporte;
use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\Collection;

class ReporteController extends Controller
{
    public function index(Request $request)
    {
        $fecha = new Carbon($request->fecha);
        if ($request->fecha) {
            $reportes = Reporte::whereMonth('fecha_reporte', $fecha->month)
                ->whereYear('fecha_reporte', $fecha->year)
                ->orderByDesc('fecha_reporte')
                ->paginate(5);
        } else {
            $reportes = Reporte::orderByDesc('fecha_reporte')
                ->paginate(5);
        }
        return view('reports.index', compact('reportes', 'fecha'));
    }
    public function show(Reporte $reporte)
    {
        try {
            $ingresos_diarios = $reporte->ingresosDiarios()->get();
            $pagos_membresias = $reporte->historialPagos()->get();
            $pagos_entrenadores = $reporte->historiales()->get();
            $vendidos_por_producto = $ingresos_diarios->where('concepto', 'Producto');
            $otros_conceptos = $ingresos_diarios->where('concepto', '!=', 'Producto');
            $ingreso_producto = new Collection();
            $ingreso_varios = new Collection();
            $ingresos_membresias = new Collection();
            $pagos = new Collection();
            $ingreso_producto_total = 0;
            $ingreso_varios_total = 0;
            $ingresos_membresias_total = 0;
            $gastos_entrenadores = 0;
            foreach ($vendidos_por_producto as $item) {
                $ingreso_producto_total += $item->cantidad * ($item->valor - $item->salida);
                $encontrado = $ingreso_producto->where('producto_sku', $item->producto->sku)->first();
                if ($encontrado) {
                    $encontrado['cantidad'] = $encontrado['cantidad'] + $item->cantidad;
                    $encontrado['salida'] = $encontrado['salida'] + $item->salida;
                    $encontrado['valorTotal'] = $encontrado['cantidad'] * ($encontrado['valor'] -  $encontrado['salida']);
                } else {
                    $ingreso_producto[] = $item;
                }
            }
            foreach ($otros_conceptos as $item) {
                $ingreso_varios_total += $item->cantidad * ($item->valor - $item->salida);
                $encontrado = $ingreso_varios->where('concepto', $item->concepto)->first();
                $total = $otros_conceptos->where('concepto', $item->concepto)->count();
                if ($encontrado) {
                    $encontrado['cantidad'] = $encontrado['cantidad'] + $item->cantidad;
                    $encontrado['valor'] = $encontrado['valor'] + $item->valor / $total;
                    $encontrado['salida'] = $encontrado['salida'] + $item->salida / $total;
                    $encontrado['valorTotal'] = $encontrado['cantidad'] * ($encontrado['valor'] -  $encontrado['salida']);
                } else {
                    $item['valor'] = $item['valor'] / $total;
                    $item['salida'] = $item['salida'] / $total;
                    $ingreso_varios[] = $item;
                }
            }
            foreach ($pagos_membresias as $item) {
                $ingresos_membresias_total += $item->valor;
                $encontrado = $ingresos_membresias->where('membresia_id', $item->membresia_id)->first();
                if ($encontrado) {
                    $encontrado['cantidad'] = $encontrado['cantidad'] + 1;
                    $encontrado['valorTotal'] = $encontrado['valorTotal'] + $item->valor;
                } else {
                    $item['cantidad'] = 1;
                    $item['valorTotal'] = $item->valor;
                    $ingresos_membresias[] = $item;
                }
            }
            foreach ($pagos_entrenadores as $item){
                $gastos_entrenadores += $item->valor_pagado;
                $encontrado = $pagos->where('usuario_id', $item->usuario_id)->first();
                if($encontrado){
                    $encontrado['total_horas'] += $item->total_horas;
                    $encontrado['valor_pagado'] += $item->valor_pagado;
                    $encontrado['fecha_hasta'] = $item->fecha_hasta;
                }else{
                    $pagos[] = $item;
                }
            }
            $total = $ingreso_producto_total + $ingreso_varios_total + $ingresos_membresias_total - $gastos_entrenadores;
            return view('reports.show',
            compact('reporte',
            'ingreso_producto',
            'ingreso_varios',
            'ingresos_membresias',
            'ingreso_producto_total',
            'ingreso_varios_total',
            'ingresos_membresias_total',
            'gastos_entrenadores',
            'pagos',
            'total'));
        } catch (Exception $e) {
            throw $e;
        }
    }
}
