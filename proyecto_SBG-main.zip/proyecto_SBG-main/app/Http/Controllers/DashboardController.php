<?php

namespace App\Http\Controllers;

use App\Models\Ejercicio;
use App\Models\Foro;
use App\Models\Evento;
use App\Models\Reporte;
use App\Models\Rutina;
use App\Models\Producto;
use Illuminate\Http\Request;
use App\Models\Usuario;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{

    public function index()
    {
        $role = Auth::user()->roles[0]->name;
        if ($role == 'Admin') {
            return $this->adminIndex();
        } elseif ($role == 'Entrenador') {
            return $this->trainerIndex();
        } elseif ($role == 'Cliente') {
            if(Auth::user()->membresia_id){
                return $this->customerIndex(Auth::user());
            }
            else{
                $route = route('landing.index').'#membresias';
                return redirect($route);
            }
        } else {
            // Manejo de caso no esperado
            return redirect()->route('landing.index');
        }
    }

    public function adminIndex()
    {
        // Fecha actual
        $fecha_actual = new Carbon(now());
        // Fecha anterior :: Mes
        $fecha_anterior = new Carbon(now()->subMonth());
        // Otras variables
        $porcentaje_ganancia = 0;

        // Conteo de elementos
        $usuarios_cliente = Usuario::role('Cliente')->count();
        $usuarios_entrenador = Usuario::role('Entrenador')->count();
        $clientes_recientes = Usuario::role('Cliente')->whereMonth('created_at', $fecha_actual->month)->whereYear('created_at', $fecha_actual->year)->get()->count();
        $rutinas = Rutina::count();
        $productos = Producto::count();

        // Ganancias por mes
        $reporte = Reporte::whereMonth('fecha_reporte', $fecha_actual->month)->whereYear('fecha_reporte', $fecha_actual->year)->first();
        $ganancias_mes = $reporte;
        // Ganancias anteriores por mes
        $ganancias_anteriores = Reporte::whereMonth('fecha_reporte', $fecha_anterior->month)
            ->whereYear('fecha_reporte', $fecha_anterior->year)
            ->first();

        // Porcentaje de ganancia :: Condicional que verifica que las ganancias anteriores no sean 0
        if ($ganancias_anteriores && $ganancias_mes) {
            if ($ganancias_anteriores->ganancia != 0) {
                $ganancia_actual = $ganancias_mes->ganancia;
                $ganancia_anterior = $ganancias_anteriores->ganancia;
                $porcentaje_ganancia = (($ganancia_actual - $ganancia_anterior) / $ganancia_anterior);
            }
        }

        // Condicionales para la verificacion de ganancias
        if ($ganancias_mes == null) {
            $ganancias_mes = 0;
        } else {
            $ganancias_mes = $ganancias_mes->ganancia;
        }

        return view('dashboard.admin', [
            'usuarios_cliente' => $usuarios_cliente,
            'usuarios_entrenador' => $usuarios_entrenador,
            'ganancias_mes' => $ganancias_mes,
            'clientes_recientes' => $clientes_recientes,
            'rutinas' => $rutinas,
            'productos' => $productos,
            'porcentaje_ganancia' => $porcentaje_ganancia,
            'reporte' => $reporte
        ]);
    }

    public function trainerIndex()
    {
        $usuario = Auth::user();
        $rutinas = Rutina::where('usuario_id', $usuario->id)->count();
        $usuarios = Usuario::role('Cliente')->count();
        $foros = Foro::where('usuario_id', $usuario->id)->count();
        return view('dashboard.trainer', compact('rutinas', 'usuarios', 'foros'));
    }
    public function customerIndex(Usuario $usuario)
    {
        $rutinas = Rutina::count();
        $entrenadores = Usuario::role('Entrenador')->count();
        $foros = Foro::count();
        $eventos = Evento::count();
        return view('dashboard.customer', compact('usuario', 'rutinas', 'entrenadores', 'foros', 'eventos'));
    }
}
