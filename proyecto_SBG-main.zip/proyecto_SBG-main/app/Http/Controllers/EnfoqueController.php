<?php

namespace App\Http\Controllers;

use App\Models\Enfoque;
use Illuminate\Http\Request;

class EnfoqueController extends Controller
{
    public function index(Request $r)
    {
        $search = $r->search;
        $enfoques = Enfoque::Where('id','ilike','%'.$search.'%')
        ->orWhere('titulo','ilike','%'.$search.'%')
        ->paginate(5);
        return view('approach.index', compact('enfoques','search'));
    }
    public function create()
    {
        return view('approach.create');
    }
    public function edit(Enfoque $enfoque)
    {
        return view('approach.edit',compact('enfoque'));
    }
    public function store(Request $r)
    {
        $this->validate($r, [
            'avatar' => 'required',
            'titulo' => 'required'
        ]);
        Enfoque::create($r->all());
        return back()->with('alert', ['type' => 'success']);
    }

    public function update(Request $r, Enfoque $enfoque)
    {
        $this->validate($r, [
            'avatar' => 'required',
            'titulo' => 'required'
        ]);
        $enfoque->update(
            $r->all()
        );
        return back()->with('alert', ['type' => 'info']);
    }

    public function destroy(Enfoque $enfoque)
    {
        $enfoque->delete();

        return back();
    }
}
