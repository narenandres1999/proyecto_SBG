<?php

namespace Database\Factories;

use App\Models\Categoria;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Producto>
 */
class ProductoFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $categorias = Categoria::where('tipo','producto')->get()->modelKeys();
        return [
            'sku' => $this->faker->ean8(),
            'nombre' => $this->faker->firstName(),
            'valor' => $this->faker->numberBetween(3000,50000),
            'cantidad' =>$this->faker->numberBetween(20,40),
            'disponible' =>$this->faker->numberBetween(20,40),
            'categoria_id' => $this->faker->randomElement($categorias)
        ];
    }
}
