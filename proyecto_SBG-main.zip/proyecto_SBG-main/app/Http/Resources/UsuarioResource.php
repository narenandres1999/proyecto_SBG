<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\ForoResource;

class UsuarioResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */

    // El siguiente método tiene como proposito devolver toda información de un usuario
    // contando también los registros asociados a él
    public function toArray(Request $request): array
    {


        return [
            'nombre_usuario' => $this->nombre_usuario,
            'email' => $this->email,
            'email_verified_at' =>  $this->email_verified_at,
            'password' =>  $this->password,
            'telefono' =>  $this->telefono,
            'fecha_nacimiento' =>  $this->fecha_nacimiento,
            'nombre' =>  $this->nombre,
            'apellidos' =>  $this->apellidos,
            'cargo' =>  $this->cargo,
            'avatar' =>  $this->avatar,
            'membresia_id' => $this->membresia_id,
            'role_principal' => $this->roles[0]->name,
            'roles' => $this->roles,
            'historial_entrenador'=> $this->historiales,
            'historialPagos' => $this->historialPagos,
            'antropometricas' => $this->antropometricas,
            'membresia' => $this->membresia,
            'observaciones' => $this->observaciones
        ];
    }
}
