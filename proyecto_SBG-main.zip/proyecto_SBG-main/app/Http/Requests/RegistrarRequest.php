<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RegistrarRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'password' => 'required|min:8',
            'password_confirm' => 'required|same:password|min:8',
            'nombre' => "required|regex:/^([A-Za-zÑñÁáÉéÍíÓóÚú]+['\-]{0,1}[A-Za-zÑñÁáÉéÍíÓóÚú]+)(\s+([A-Za-zÑñÁáÉéÍíÓóÚú]+['\-]{0,1}[A-Za-zÑñÁáÉéÍíÓóÚú]+))*$/iu",
            'apellidos' => "required|regex:/^([A-Za-zÑñÁáÉéÍíÓóÚú]+['\-]{0,1}[A-Za-zÑñÁáÉéÍíÓóÚú]+)(\s+([A-Za-zÑñÁáÉéÍíÓóÚú]+['\-]{0,1}[A-Za-zÑñÁáÉéÍíÓóÚú]+))*$/iu",
            'email' => 'required|email',
            'fecha_nacimiento' => 'date',
            'terminos' => 'required',
            'telefono' => 'required|numeric|digits_between:7,10',
        ];
    }
    public function attributes(): array
    {
        return [
            'password' => 'contraseña',
            'password_confirm' => 'confirmar contraseña',
            'nombre' => 'nombres',
            'apellidos' => 'apellidos',
            'email' => 'correo electrónico',
            'fecha_nacimiento' => 'fecha de nacimiento',
            'terminos' => 'terminos',
            'telefono' => 'número telefónico',
        ];
    }
    function messages(): array
    {
        return [
            'nombre.regex' => 'Este campo solo permite letras',
            'apellidos.regex' => 'Este campo solo permite letras',
        ];
    }
}
