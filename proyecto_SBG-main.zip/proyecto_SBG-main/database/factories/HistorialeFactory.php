<?php

namespace Database\Factories;

use App\Models\Reporte;
use App\Models\Usuario;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Historiale>
 */
class HistorialeFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $reportes = Reporte::all()->modelKeys();
        $usuarios = Usuario::all()->modelKeys();
        return [
            'fecha_pago' => $this->faker->dateTimeBetween('-3 years', 'now'),
            'valor_hora' => 8000,
            'fecha_desde' => $this->faker->dateTimeBetween('-1 years','now'),
            'fecha_hasta' => $this->faker->dateTimeBetween('-1 years','now'),
            'valor_pagado' => 1000000,
            'total_horas' => 300,
            'reporte_id' => $this->faker->randomElement($reportes),
            'usuario_id' => $this->faker->randomElement($usuarios)
        ];
    }
}
