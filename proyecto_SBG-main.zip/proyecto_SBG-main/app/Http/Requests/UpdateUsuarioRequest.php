<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateUsuarioRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'nombre' => 'required',
            'apellidos' => 'required',
            'email' => 'required|email',
            'fecha_nacimiento' => 'date',
            'telefono' => 'required',
            'direccion',
            // 'membresia_id' => 'required|numeric',
        ];
    }
    public function attributes(): array
    {
        return [
            'password' => 'contraseña',
            'password_confirm' => 'confirmar contraseña',
            'nombre' => 'nombres',
            'apellidos' => 'apellidos',
            'email' => 'correo electrónico',
            'fecha_nacimiento' => 'fecha nacimiento',
            'telefono' => 'telefono',
            'direccion' => 'direccion',
            'membresia_id' => 'membresia',
            'role' => 'tipo de usuario'
        ];
    }
    function messages():array
    {
        return [
            'password.required' => 'Por favor ingrese una contraseña'
        ];

    }
}
