<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AntropometricaRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'fecha' => 'required|date',
            'estatura' => 'required|decimal:2',
            'peso' => 'required|decimal:1',
            'busto-torax' => 'required|decimal:1',
            'hombro' => 'required|decimal:1',
            'brazo' => 'required|decimal:1',
            'cintura' => 'required|decimal:1',
            'cadera' => 'required|decimal:1',
            'pierna' => 'required|decimal:1',
            'IMC' => 'required|decimal:1',
        ];
    }
    public function attributes(): array
    {
        return ['busto-torax' => 'busto o torax'];
    }
    public function messages(): array
    {
        return [];
    }
}
