<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreProductoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'sku' => 'required|string',
            'nombre' => 'required|string|max:120',
            'categoria_id' => 'required|string|max:120',
            'valor' => 'required|numeric',
            'cantidad' => 'required|numeric|min: 1',
            'disponible' => 'required|numeric|lte:cantidad',
        ];
    }
    public function attributes(): array
    {
        return [
            'sku' => 'Código de producto',
            'cantidad' => 'cantidad inicial',
            'categoria_id' => 'categoria'
        ];
    }
    function messages():array
    {
        return [
        ];

    }
}
