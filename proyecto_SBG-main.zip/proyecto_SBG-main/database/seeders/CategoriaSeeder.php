<?php

namespace Database\Seeders;

use App\Models\Categoria;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CategoriaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Categoria::create(['nombre' => 'Producto','tipo' => 'ingresos_diarios']);
        Categoria::create(['nombre' => 'Servicio público','tipo' => 'ingresos_diarios']);
        Categoria::create(['nombre' => 'Entrenamiento','tipo' => 'ingresos_diarios']);
    }
}
