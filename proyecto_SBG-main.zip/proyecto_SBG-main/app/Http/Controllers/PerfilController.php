<?php

namespace App\Http\Controllers;

use App\Models\TypeIdentification;
use Illuminate\Http\Request;
use App\Models\Usuario;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Exception;
use GuzzleHttp\Promise\Promise;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;

class PerfilController extends Controller
{
    public function index(Usuario $usuario)
    {
        $tipos_documentos = TypeIdentification::all();
        return view('account/index', compact('usuario', 'tipos_documentos'));
    }
    public function update(Request $request)
    {
        try {
            $usuario = Usuario::find(Auth::user()->id);
            // Pendiente todas las especificaciones de valores validos en el formulario
            $this->validate($request, [
                'telefono',
                'direccion',
                'avatar',
                'type_identification_id',
                'documento'
            ]);
            if ($request->documento && !$request->type_identification_id) {
                back()->withErrors(['type_identification_id' => 'seleccione el tipo de documento']);
                throw new Exception("");
            } else {
                $usuario->type_identification_id = $request->input('type_identification_id');
                $usuario->documento = $request->input('documento');
            }
            $usuario->direccion = $request->input('direccion');
            $usuario->fecha_nacimiento = $request->input('fecha_nacimiento');
            $usuario->update();
            return redirect()->route('perfil.index', $usuario)->with('alert', ['type' => 'info',]);
        } catch (Exception $e) {
            if ($e->getMessage() != "") {
                throw $e;
                return back()->with('alert', ['type' => 'error']);
            }
            return back()->with('alert', ['type' => 'error']);
        }
    }
    public function updatePassword(Request $request)
    {
        try {
            $this->validate($request, [
                'password' => 'required',
                'new_password' => 'required|digits_between:8,30',
                'confirm_password' => 'required|same:new_password|digits_between:8,30',
            ], [], [
                'password' => "contraseña",
                'new_password' => "nueva contraseña",
                'confirm_password' => "confirmar contraseña",
            ]);
            $usuario = Usuario::find(Auth::user()->id);
            // print(Hash::check($request->password,$usuario->password));
            if (Hash::check($request->password, $usuario->password)) {
                $usuario->password = Hash::make($request->confirm_password);
                $usuario->save();
                Auth::logout();
                return redirect()->route('landing.index')->with('alert', ['type' => 'info',]);
            } else {
                back()->withErrors(['password' => 'contraseña incorrecta, por favor ingrese su contraseña actual']);
                throw new Exception("");
            }
        } catch (Exception $e) {
            if ($e->getMessage() != "") {
                throw $e;
                return back()->with('alert', ['type' => 'error']);
            } else {
                return back();
            }
        }
    }

    public function updatePhoto(Request $request)
    {

        $input = $request->all();
        $rules = ['imageUpload' => 'required'];
        $messages = [];
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            $arr = array("status" => 400, "msg" => $validator->errors()->first(), "result" => array());
        } else {
            try {
                if ($input['base64image'] || $input['base64image'] != '0') {

                    $folderPath = public_path('media/avatars/');

                    $image_parts = explode(";base64,", $input['base64image']);

                    $image_type_aux = explode("image/", $image_parts[0]);

                    $image_type = $image_type_aux[1];
                    $image_base64 = base64_decode($image_parts[1]);
                    // $file = $folderPath . uniqid() . '.png';

                    $usuario = Usuario::find(Auth::user()->id);
                    $filename = $usuario->id . '.' . $image_type;
                    $file = $folderPath . $filename;
                    file_put_contents($file, $image_base64);
                    new Promise(function ($file, $image_base64) {
                        file_put_contents($file, $image_base64);
                    });
                    $usuario->avatar = $filename;
                    $usuario->save();
                    $usuario->fresh();
                }
                $msg = 'Image upload successfully.';
                Session::flash('message', $msg);
            } catch (\Illuminate\Database\QueryException $ex) {
                $msg = $ex->getMessage();
                if (isset($ex->errorInfo[2])) {
                    $msg = $ex->errorInfo[2];
                }
                Session::flash('error', $msg);
            } catch (Exception $ex) {
                $msg = $ex->getMessage();
                Session::flash('error', $msg);
            }
        }
        // // $this->index();
        return back()->with('alert', ['type' => 'info',]);
    }

    public function deletePhoto()
    {
        $usuario = Usuario::find(Auth::user()->id);
        $folderPath = public_path('media/avatars/');
        $filename = $folderPath . $usuario->avatar;
        unlink($filename);
        $usuario->update([
            'avatar' => null
        ]);
        return redirect()->route('perfil.index', $usuario)->with('alert', ['type' => 'success']);
    }
}
