<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RutinaResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'dificultad' => $this->dificultad,
            'enfoque' => $this->enfoque,
            'usuario' => $this->usuario,
            'ejercicios' => $this->enfoque->ejercicios()->wherePivot('rutina_id', $this->id)->get()
        ];
    }
}
