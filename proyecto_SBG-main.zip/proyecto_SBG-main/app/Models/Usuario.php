<?php

namespace App\Models;

use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\CanResetPassword;
use Illuminate\Auth\Passwords\CanResetPassword as ResetPassword;
use Illuminate\Foundation\Auth\User as Authenticatables;
use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Spatie\Permission\Traits\HasRoles;
use App\Models\Observacione;
use App\Models\Historiale;
use App\Models\Historial_pago;
use App\Models\Antropometrica;
use App\Models\Membresia;
use App\Models\Foro;
use App\Models\Rutina;
use Illuminate\Database\Eloquent\SoftDeletes;

class Usuario extends Authenticatables implements AuthenticatableContract, MustVerifyEmail, CanResetPassword
{
    use HasFactory, HasUuids, HasRoles, Notifiable, SoftDeletes, Authenticatable, ResetPassword;
    // Se define un guard_name para poder usar los roles
    protected $guard_name = 'web';

    protected $hidden = [
        'password',
        'email',
        'id'
    ];
    protected $guarded = [];
    // Definición de los métodos de relaciones

    // Obtiene las observaciones asignadas al usuario (cuando se generan antropometricas)
    public function observaciones(): HasMany
    {
        return $this->hasMany(Observacione::class);
    }
    public function asistencias(): HasMany
    {
        return $this->hasMany(Asistencia::class);
    }
    // Obtiene el historial de pagos del entrenador
    public function historiales(): HasMany
    {
        return $this->hasMany(Historiale::class);
    }
    // Obtiene el historial de pagos realizados o pendientes del usuario (cliente)
    public function historialPagos(): HasMany
    {
        return $this->hasMany(Historial_pago::class);
    }
    // Obtiene las medidas antropometricas del cliente
    public function antropometricas(): HasMany
    {
        return $this->hasMany(Antropometrica::class);
    }
    // Muestra la membresia vinculada al cliente
    public function membresia(): BelongsTo
    {
        return $this->belongsTo(Membresia::class)->withDefault();
    }
    public function typeIdentification(): BelongsTo
    {
        return $this->belongsTo(TypeIdentification::class)->withDefault();
    }
    // Muestra todos los foros publicados por el usuario
    public function foros(): HasMany
    {
        return $this->hasMany(Foro::class);
    }
    // Muestra las rutinas publicadas por el usuario
    public function rutinas(): HasMany
    {
        return $this->hasMany(Rutina::class);
    }

    public function tituloAcademicos(): HasMany
    {
        return $this->hasMany(TituloAcademico::class);
    }
}
