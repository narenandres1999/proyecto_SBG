<?php

namespace App\Http\Controllers;

use App\Http\Requests\RegistrarRequest;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Auth\Events\PasswordReset;
use App\Models\Usuario;
use Illuminate\Support\Str;
use Illuminate\Validation\Validator;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\URL;

class LoginController extends Controller
{

    public function index()
    {
    }

    public function login(Request $request)
    {
        return view('auth.login');
    }
    public function register()
    {
        return view('auth.register');
    }
    public function authenticate(Request $request): RedirectResponse
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);
        $usuario = Usuario::withTrashed()->where('email', $credentials['email'])->first();
        if (!$usuario) {
            return back()->withErrors([
                'email' => 'No existe un usuario con ese correo',
            ])->withInput();
        }
        if ($usuario->deleted_at) {
            return back()->withErrors([
                'email' => 'Cuenta inactiva, pongase en contacto con el administrador',
            ])->withInput();
        }
        if (!(Hash::check($credentials['password'], $usuario->password))) {
            return back()->withErrors([
                'password' => 'Contraseña incorrecta',
            ])->withInput();
        }
        if (Auth::attempt($credentials)) {
            $request->session()->put('user_id', Auth::user()->id);
            $request->session()->regenerate();
            return redirect("/dashboard");
        }
    }

    public function logout(Request $request): RedirectResponse
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('landing.index');
    }


    public function crearUsuario(RegistrarRequest $request)
    {
        $existe = Usuario::where('email', $request->email)->count();
        if ($existe > 0) {
            return back()->withErrors(['email' => "este correo ya está registrado"])->withInput($request->except(['password_confirm', 'terminos']));
        }
        if ($request->terminos == 'aceptado') {
            $request['suscripcion_activa'] = null;
            $input = $request->except(['password_confirm', 'terminos','_token']);
            $input['password'] = Hash::make($input['password']);
            $usuario = Usuario::create($input)->assignRole('Cliente');
            event(new Registered($usuario));
            $route = route('landing.index').'#membresias';
            Auth::loginUsingId($usuario->id);
            return redirect($route)->with('alert', ['type' => 'registro']);
        } else {
            return back()->withInput($request->except(['password_confirm', 'terminos']))->with('alert',['type' => 'error']);
        }
    }

    public function forgotPassword()
    {
        return view('auth.forgot');
    }
    public function sendResetLink(Request $request)
    {
        $request->validate(['email' => 'required|email']);

        $status = Password::sendResetLink(
            $request->only('email')
        );
        return $status === Password::RESET_LINK_SENT
            ? redirect()->route('login.login')->with(['status' => __($status)])
            : redirect()->route('forgot-password')->withErrors(['email' => __($status)]);
    }

    public function resetPassword(string $token)
    {
        return view('auth.reset-password', ['token' => $token]);
    }

    public function storePassword(Request $request)
    {
        $request->validate([
            'token' => 'required',
            'email' => 'required|email',
            'password' => 'required|min:8|confirmed',
        ]);

        $status = Password::reset(
            $request->only('email', 'password', 'password_confirmation', 'token'),
            function (Usuario $user, string $password) {
                $user->forceFill([
                    'password' => Hash::make($password)
                ])->setRememberToken(Str::random(60));

                $user->save();

                event(new PasswordReset($user));
            }
        );

        return $status === Password::PASSWORD_RESET
            ? redirect()->route('login.login')->with('status', __($status))
            : back()->withErrors(['email' => [__($status)]]);
    }
    /*
    public function confirmar_password(){
        return "Ira una vista con un modal o redireccion para confirmar contraseña para momentos delicados";
    }

    public function validar(Request $request) {
        if (! Hash::check($request->password, $request->user()->password)) {
            return back()->withErrors([
                'password' => ['The provided password does not match our records.']
            ]);
        }

        $request->session()->passwordConfirmed();

        return redirect()->intended();
    }
    */
}
