<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Enfoque;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Ejercicio extends Model
{
    use HasFactory,SoftDeletes;
    protected $guarded = [];
    // Definición de los métodos de relaciones
    public function enfoques(): BelongsToMany
    {
        return $this->belongsToMany(Enfoque::class)->withPivot('repeticiones', 'series','rutina_id');
    }
    public function categoria(): BelongsTo
    {
        return $this->belongsTo(Categoria::class);
    }
}
