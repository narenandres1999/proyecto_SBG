<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;

use App\Models\Antropometrica;
use App\Models\Categoria;
use Illuminate\Database\Seeder;
use App\Models\Usuario;
use App\Models\Membresia;
use App\Models\Producto;
use App\Models\Reporte;
use App\Models\Rutina;
use App\Models\Enfoque;
use App\Models\Ejercicio;
use App\Models\Evento;
use App\Models\Foro;
use App\Models\Historial_pago;
use App\Models\Historiale;
use App\Models\Ingresos_diario;
use App\Models\Observacione;
use App\Models\PseBanco;
use App\Models\TituloAcademico;
use App\Models\TypeIdentification;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Accept' => 'application/json'
        ])->post(env('PAYU_BASE_URL') . 'payments-api/4.0/service.cgi', [
            'language' => 'es',
            'command' => 'GET_BANKS_LIST',
            'merchant' => [
                'apiLogin' => env('PAYU_SECRET'),
                'apiKey' => env('PAYU_KEY')
            ],
            'test' => true,
            'bankListInformation' => [
                'paymentMethod' => 'PSE',
                'paymentCountry' => 'CO'
            ]
        ]);
        foreach ($response->json()['banks'] as $banco) {
            PseBanco::firstOrCreate($banco);
        }
        $this->call([RoleSeeder::class, CategoriaSeeder::class]);
        Reporte::factory(10)->create();
        Categoria::factory(20)->create();
        Membresia::factory(10)->create();
        Enfoque::factory(20)->create();
        Producto::factory(20)->create();
        TypeIdentification::create(['codigo' => 'CC', 'nombre_documento' => 'Cédula de ciudadanía']);
        TypeIdentification::create(['codigo' => 'CE', 'nombre_documento' => 'Cédula de extranjería']);
        TypeIdentification::create(['codigo' => 'TI', 'nombre_documento' => 'Tarjeta de identidad']);
        TypeIdentification::create(['codigo' => 'DE', 'nombre_documento' => 'Documento de identificación']);
        TypeIdentification::create(['codigo' => 'NIT', 'nombre_documento' => 'Número de Identificación']);
        TypeIdentification::create(['codigo' => 'PP', 'nombre_documento' => 'Pasaporte']);
        TypeIdentification::create(['codigo' => 'RC', 'nombre_documento' => 'Registro civil de nacimiento']);
        $usuario1 = Usuario::factory(200)->create();
        Evento::factory(30)->create();
        $contador = 1;
        foreach ($usuario1 as $usuario) {
            if ($contador == 1) {
                $usuario->assignRole('Admin');
            }
            if ($contador == 2) {
                $usuario->assignRole('Entrenador');
            }
            if ($contador == 3) {
                $usuario->assignRole('Cliente');
                $data = [
                    'proxima_generacion' => now(),
                    'suscripcion_activa' => 1
                ];
                $usuario->update($data);
            }
            $contador++;
            if ($contador > 3) {
                $contador = 1;
            }
        }
        Antropometrica::factory(600)->create();
        Foro::factory(20)->create();
        Observacione::factory(600)->create();
        Historial_pago::factory(400)->create();
        Historiale::factory(100)->create();
        TituloAcademico::factory(400)->create();
        Ingresos_diario::factory(400)->create();
        $rutinas = Rutina::factory(20)->create();
        $ejercicios = Ejercicio::factory(20)
            ->create();
        $total_ejercicios = $ejercicios->count();
        foreach ($rutinas as $rutina) {
            for ($i = 0; $i < 5; $i++) {
                $rutina->enfoque->ejercicios()->attach(fake()->numberBetween(1, $total_ejercicios), [
                    'repeticiones' => fake()->numberBetween(1, 10),
                    'series' => fake()->numberBetween(1, 10),
                    'rutina_id' => $rutina->id
                ]);
            }
        }
        Usuario::firstOrCreate([
            'email' => "admin@gmail.com",
            'password' => Hash::make('password'),
            'telefono' => '3145454822',
            'fecha_nacimiento' => '1999-07-26',
            'nombre' => 'Naren Admin',
            'apellidos' => 'Medina',
            'email_verified_at' => now(),
            'direccion' => 'Calle 10 # 27 AS 04',
            'membresia_id' => null,
            'proxima_generacion' => null,
            'suscripcion_activa' => 0,
            'documento' => "1006288469",
            'type_identification_id' => 1
        ])->assignRole('Admin');
        Usuario::firstOrCreate([
            'email' => "entrenador@gmail.com",
            'password' => Hash::make('password'),
            'telefono' => '3145454822',
            'fecha_nacimiento' => '1999-07-26',
            'nombre' => 'Naren Entrenador',
            'apellidos' => 'Medina',
            'email_verified_at' => now(),
            'direccion' => 'Calle 10 # 27 AS 04',
            'membresia_id' => null,
            'proxima_generacion' => null,
            'suscripcion_activa' => 0,
            'documento' => "1006288469",
            'type_identification_id' => 1
        ])->assignRole('Entrenador');
        Usuario::firstOrCreate([
            'email' => "cliente@gmail.com",
            'password' => Hash::make('password'),
            'telefono' => '3145454822',
            'fecha_nacimiento' => '1999-07-26',
            'nombre' => 'Naren Cliente',
            'apellidos' => 'Medina',
            'email_verified_at' => now(),
            'direccion' => 'Calle 10 # 27 AS 04',
            'membresia_id' => null,
            'proxima_generacion' => now(),
            'suscripcion_activa' => 1,
            'documento' => "1006288469",
            'type_identification_id' => 1
        ])->assignRole('Cliente');
    }
}
