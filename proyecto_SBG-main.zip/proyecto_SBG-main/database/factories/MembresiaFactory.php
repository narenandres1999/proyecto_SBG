<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Membresia>
 */
class MembresiaFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $duracion_dias = $this->faker->numberBetween(1,3);
        return [
            'duracion_dias' => $duracion_dias,
            'valor' => ($duracion_dias * 2000),
            'titulo' => "membresia {$duracion_dias}",
            'descripcion' => $this->faker->paragraph(3),
        ];
    }
}
