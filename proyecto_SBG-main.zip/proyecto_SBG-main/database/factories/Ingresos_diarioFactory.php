<?php

namespace Database\Factories;

use App\Models\Producto;
use App\Models\Reporte;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Ingresos_diario>
 */
class Ingresos_diarioFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $concepto = $this->faker->randomElement(['Producto', 'Servicio público', 'Entrenamiento']);
        $ids_reportes = Reporte::all()->modelKeys();
        $producto_sku = null;
        $productos = Producto::all();
        $valor = 5000;
        $cantidad = $this->faker->numberBetween(5, 20);
        $salida = 0;
        $valorTotal = 0;
        if ($concepto == 'Producto') {
            $selected = $this->faker->randomElement($productos->modelKeys());
            $selectedProducto = $productos->where('sku', $selected)->first();
            $producto_sku = $selectedProducto->sku;
            $valor = $selectedProducto->valor;
        }
        if ($concepto == 'Servicio público') {
            $valor = 0;
            $salida = $this->faker->numberBetween(10000, 40000);
        }
        $valorTotal = $cantidad * ($valor - $salida);
        return [
            'concepto' => $concepto,
            'cantidad' => $cantidad,
            'valor' => $valor,
            'salida' => $salida,
            'valorTotal' => $valorTotal,
            'reporte_id' => $this->faker->randomElement($ids_reportes),
            'producto_sku' => $producto_sku
        ];
    }
}
