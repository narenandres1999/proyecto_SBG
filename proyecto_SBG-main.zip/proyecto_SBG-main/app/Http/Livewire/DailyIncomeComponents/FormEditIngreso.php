<?php

namespace App\Http\Livewire\DailyIncomeComponents;

use App\Models\Categoria;
use App\Models\Producto;
use Livewire\Component;

class FormEditIngreso extends Component
{
    public $selectedConcepto = null, $selectedProducto = '';
    public $valueCantidad = 0, $valuePrecio = 0, $valueValorTotal = 0, $valueSalida = 0;
    public $datosProductos = null;
    public $otro = null;
    public $editable = false;
    public $ingreso = null;
    public $conceptos = null;
    public function mount()
    {
        $this->valueCantidad = $this->ingreso->cantidad;
        $this->valuePrecio = $this->ingreso->valor;
        $this->valueValorTotal = $this->ingreso->valorTotal;
        $this->valueSalida = $this->ingreso->salida;
        $this->conceptos = Categoria::where('tipo','ingresos_diarios')->get();
        if (!(Categoria::where('tipo','ingresos_diarios')->where('nombre',$this->ingreso->concepto)->first())){
            $this->selectedConcepto = 'otro';
            $this->otro = $this->ingreso->concepto;
        }else{
            $this->selectedConcepto = $this->ingreso->concepto;
        }
        if ($this->ingreso->concepto == 'Producto') {
            $this->datosProductos = Producto::orderBy('nombre')->get();
            $this->editable = true;
        }
        $this->selectedProducto = $this->ingreso->producto->sku;
    }
    public function render()
    {
        return view('livewire.daily-income-components.form-edit-ingreso');
    }
    public function updatedselectedConcepto()
    {
        if ($this->selectedConcepto == 'Producto') {
            $this->datosProductos = Producto::orderBy('nombre')->get();
            $this->editable = true;
        } else {
            $this->datosProductos = null;
            $this->selectedProducto = '';
            $this->editable = false;
        }
    }
    public function updatedvalueCantidad()
    {
        $this->valueValorTotal =  intval($this->valueCantidad) * (intval($this->valuePrecio) - intval($this->valueSalida));
    }
    public function updatedvaluePrecio()
    {
        $this->valueValorTotal = intval($this->valueCantidad) * (intval($this->valuePrecio) - intval($this->valueSalida));
    }
    public function updatedvalueSalida($salida)
    {
        $this->valueValorTotal = intval($this->valueCantidad) * (intval($this->valuePrecio) - intval($this->valueSalida));
    }
    public function updatedselectedProducto($sku)
    {
        if ($sku) {
            $producto = Producto::where('sku', $sku)->first();
            $this->editable = true;
            $this->valuePrecio = $producto->valor;
            $this->valueValorTotal = intval($this->valueCantidad) * (intval($this->valuePrecio) - intval($this->valueSalida));
        } else {
            $this->editable = false;
            $this->valuePrecio = 0;
        }
    }
}
