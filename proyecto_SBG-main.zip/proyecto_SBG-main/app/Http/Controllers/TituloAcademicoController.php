<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TituloAcademico;
use App\Models\Usuario;
use Illuminate\Database\Eloquent\Collection;

class TituloAcademicoController extends Controller
{
    public function update(Request $request, Usuario $usuario)
    {
        $usuario->tituloAcademicos()->delete();
        if($request->titulos){
            foreach($request->titulos as $titulo){
                if($titulo['nombre']){
                    TituloAcademico::create([
                        'titulo_academico' => $titulo['nombre'],
                        'usuario_id' => $usuario->id
                    ]);
                }
            }
        }
        return back()->with('alert',['type' => 'info']);
    }
    public function destroy(TituloAcademico $titulo)
    {
        $titulo->delete();
        return back()->with('alert', ['type' => 'succees']);
    }
}
