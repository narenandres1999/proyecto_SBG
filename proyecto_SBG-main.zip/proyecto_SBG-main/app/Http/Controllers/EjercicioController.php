<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use App\Models\Ejercicio;
use Illuminate\Http\Request;

class EjercicioController extends Controller
{
    public function index(Request $r)
    {
        $search = $r->search;
        $ejercicios = Ejercicio::Where('id', 'ilike', '%' . $search . '%')
            ->orWhere('nombre', 'ilike', '%' . $search . '%')
            ->orWhereRelation('categoria', 'nombre', 'ilike', '%' . $search . '%')
            ->paginate(5);
        return  view('exercises.index', compact('ejercicios', 'search'));
    }
    public function create()
    {
        $categorias = Categoria::where('tipo', 'ejercicio')->orderBy('nombre')->get();
        return view('exercises.create', compact('categorias'));
    }
    public function edit(Ejercicio $ejercicio)
    {
        $categorias = Categoria::where('tipo', 'ejercicio')->orderBy('nombre')->get();
        return view('exercises.edit', compact('ejercicio','categorias'));
    }
    public function store(Request $r)
    {
        $this->validate($r, [
            'nombre' => 'required|max:100'
        ]);
        if ($r->categoria_id == 'add-category') {
            if (!$r->nueva_categoria) {
                return back()->withErrors(['nueva_categoria' => 'Agrege el nombre de la nueva categoría'])->withInput($r->all());
            }
            $nueva_categoria = Categoria::create([
                'nombre' => $r->nueva_categoria,
                'tipo' => 'ejercicio'
            ]);
            $nueva_categoria->ejercicios()->create($r->except(['nueva_categoria', 'categoria_id']));
        } else {
            Ejercicio::create($r->except(['nueva_categoria']));
        }
        return redirect()->route('ejercicio.index')->with('alert', ['type' => 'success']);
    }
    public function update(Request $r, Ejercicio $ejercicio)
    {
        $this->validate($r, [
            'nombre' => 'required|max:100'
        ]);
        if ($r->categoria_id == 'add-category') {
            if (!$r->nueva_categoria) {
                return back()->withErrors(['nueva_categoria' => 'Agrege el nombre de la nueva categoría'])->withInput($r->all());
            }
            $nueva_categoria = Categoria::create([
                'nombre' => $r->nueva_categoria,
                'tipo' => 'ejercicio'
            ]);
            $r['categoria_id'] = $nueva_categoria->id;

            $ejercicio->update($r->except(['nueva_categoria']));
        } else {
            $ejercicio->update($r->except(['nueva_categoria']));
        }
        return redirect()->route('ejercicio.index')->with('alert', ['type' => 'info']);
    }
    public function destroy(Ejercicio $ejercicio)
    {
        $ejercicio->delete();
        return back();
    }
}
