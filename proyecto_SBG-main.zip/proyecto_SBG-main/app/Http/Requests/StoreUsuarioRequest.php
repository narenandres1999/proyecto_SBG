<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreUsuarioRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        $membresia_id = '';
        if ($this->role == 'Cliente') {
            $membresia_id = 'required|numeric';
        }
        return [
            // 'nombre' => 'required|regex:/^([A-Za-zÑñ]+[áéíóú]?[A-Za-z]+\s*){3,30}$/iu',
            // 'apellidos' => 'required|regex:/^([A-Za-zÑñ]+[áéíóú]?[A-Za-z]+\s*){3,30}$/iu',
            'nombre' => "required|regex:/^([A-Za-zÑñÁáÉéÍíÓóÚú]+['\-]{0,1}[A-Za-zÑñÁáÉéÍíÓóÚú]+)(\s+([A-Za-zÑñÁáÉéÍíÓóÚú]+['\-]{0,1}[A-Za-zÑñÁáÉéÍíÓóÚú]+))*$/iu",
            'apellidos' => "required|regex:/^([A-Za-zÑñÁáÉéÍíÓóÚú]+['\-]{0,1}[A-Za-zÑñÁáÉéÍíÓóÚú]+)(\s+([A-Za-zÑñÁáÉéÍíÓóÚú]+['\-]{0,1}[A-Za-zÑñÁáÉéÍíÓóÚú]+))*$/iu",
            'email' => 'required|email',
            'fecha_nacimiento' => 'date',
            'telefono' => 'required',
            'direccion',
            'membresia_id' => $membresia_id,
            'role' => 'required',
            'password' => 'required|min:8',
            'password_confirm' => 'required|same:password'
        ];
    }
    public function attributes(): array
    {
        return [
            'password' => 'contraseña',
            'password_confirm' => 'confirmar contraseña',
            'nombre' => 'nombres',
            'apellidos' => 'apellidos',
            'email' => 'correo electrónico',
            'fecha_nacimiento' => 'fecha nacimiento',
            'telefono' => 'telefono',
            'direccion' => 'direccion',
            'membresia_id' => 'membresia',
            'role' => 'tipo de usuario'
        ];
    }
    function messages(): array
    {
        return [
            'password.required' => 'Por favor ingrese una contraseña',
            'password_confirm.required' => 'Por favor confirme la contraseña',
            'password_confirm.same' => 'la contraseñas no coinciden'
        ];
    }
}
