<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Observacione;
use App\Models\Usuario;
use Exception;

class ObservacioneController extends Controller
{
    public function index(String $usuario)
    {
        $observaciones = Observacione::where('usuario_id', $usuario)->paginate();
        return $observaciones;
    }
    public function create(Usuario $usuario)
    {
        return view('observations.create', compact('usuario'));
    }

    public function store(Request $request, String $usuario)
    {
        try {
            $this->validate($request, [
                'fecha' => 'required|date',
                'descripcion' => 'required|string',
            ]);
            $request['usuario_id'] = $usuario;
            $create = Observacione::create($request->all());
            return redirect()->route('usuarios.show', compact('usuario'))->with('alert', ['type' => 'success']);
        } catch (Exception $e) {
            throw $e;
            return back()->with('alert', ['type' => 'error']);
        }
    }

    public function show(string $observacione)
    {
        $encontrado = Observacione::find($observacione);
        return $encontrado;
    }

    public function edit(Observacione $observacione)
    {

        return view('observations.edit', compact('observacione'));
    }

    public function update(Request $request, Observacione $observacione)
    {
        try {
            $this->validate($request, [
                'fecha' => 'date',
                'descripcion' => 'string'
            ]);
            $observacione->update($request->all());
            return redirect()->route('usuarios.show', ['usuario' => $observacione->usuario_id]);
        } catch (Exception $e) {
            throw $e;
            return back()->with('alert', ['type' => 'error']);
        }
    }

    public function destroy(Observacione $observacione)
    {
        $observacione->forceDelete();
    }
}
