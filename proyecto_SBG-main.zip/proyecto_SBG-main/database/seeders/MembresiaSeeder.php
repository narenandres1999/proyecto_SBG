<?php

namespace Database\Seeders;

use App\Models\Membresia;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class MembresiaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Membresia::create([
            'titulo' => 'Membresía quincenal',
            'descripcion' => '',
            'valor' => 30000,
            'duracion_dias' => 15
        ]);
        Membresia::create([
            'titulo' => 'Membresía mensual',
            'descripcion' => '',
            'valor' => 60000,
            'duracion_dias' => 30
        ]);
        Membresia::create([
            'titulo' => 'Membresía de 2 meses',
            'descripcion' => '',
            'valor' => 100000,
            'duracion_dias' => 60
        ]);
        Membresia::create([
            'titulo' => 'Membresía semestral',
            'descripcion' => '',
            'valor' => 260000,
            'duracion_dias' => 180
        ]);
    }
}
