<p align="center"><h2>Aplicativo Web para el gimnasio Sport Body Gym</h2></p>

## Desarrolladores del aplicativo Web

las personas encargadas del desarrollo del proyecto son estudiantes de la Universidad del Valle ubicada en Palmira, Valle del Cauca, Colombía. Los nombres de los integrantes son: - Naren Andres Medina Jaramillo (desarrollador Backend) - Andrés Felipe Osorio Alarcón (desarrollador Frontend)

## Descripción del proyecto

El proyecto está desarrollado en un framework php llamado Laravel, framework cómodo de utilizar y con una documentación muy completa, para aprender más de este framework visite la siguiente página [documentation Laravel](https://laravel.com/docs)

Es una aplicación desarrollada en web con el propósito de facilitar el trabajo al gimnasio Sport Body Gym ubicado en Cerrito Valle del Cauca, las funciones implementadas en el proyecto se explican a continuación.

## Funciones del proyecto

-   **Gestion de Usuarios**

    -   Creación de usuarios, clientes del gimnasio, entrenadores, administradores.
    -   Edición e inhabilitación de cuentas (esta acción solo lo puede hacer el administrador).

-   **Gestion Contable**

    -   Ingresos diarios
        -   Visualización de todos los ingresos registrados por el administrador.
        -   Creación de nuevos ingresos diarios, estos son registrados por el administrador cuando vende algún producto o gasta en el gimnasio, ejemplo: Venta de un entrenamiento diario, un suplemento o un gasto por servicio público.
        -   Edición y eliminación
    -   Historiales de pago
        -   Visualización de todos los cobros hacia los clientes generados automáticamente por el sistema, son cobros por membresía.
        -   Edición del estado de pago, está acción se utiliza cuando un cliente le paga en efectivo al encargado, el usuario administrador modifica el estado de pago a "Pagado".
        -   Visualización del cliente, acción para ver más a detalle la información del cliente.
    -   Pagos a entrenadores
        -   Gestión de asistencias, el administrador encargado registra la asistencia de sus entrenadores al gimnasio con el propósito de llevar el control de las horas laburadas, solo presiona en el día que quiere asignar la asistencia y selecciona el entrenador que asistio y la cantidad de horas trabajadas.
        -   Lista de pagos, se visualizan los diferentes pagos que ha generado el administrador a sus entrenadores.
        -   Añadir nuevos pagos, se pide seleccionar el entrenador la fecha de donde hasta donde se le pagará y el sistema ya calcula el total de horas que se registraron en la asistencia para dicho entrenador en esas fechas.
    -   Reportes Mensuales
        -   Listado de todos los reportes generados por el sistema, todas las acciones nombradas anteriormente se añaden al reporte, es una información detallada de las ganancias y gastos que se lleva en el gimnasio en el mes actual o anteriores dependiendo cuál desee consultar.

-   **Gestion de Contenido**
    -   Foro
        -   Visualización de todas las publicaciones generadas por los administradores y entrenadores
        -   Creación de nuevos foros, el propósito de este apartado es publicar consejos, recomendaciones, entre otras ideas que les gustaría mostrar a los clientes.
        -   Edición y eliminación
    -   Actividades
        -   Visualización de todas las actividades o eventos que el gimnasio va a realizar, también son notificadas al correo de los clientes al momento de su publicación.
        -   Creación, edición y eliminación de las actividades, los administradores y entrenadores pueden publicar actividades que se realizarán en el gimnasio.
    -   Rutinas
        -   Visualización de todas las rutinas de ejercicios publicadas por los administradores y entrenadores.
        -   Creación, edición y eliminación de rutinas de ejercicio, los administradores y entrenadores pueden publicar rutinas de ejercicios para los clientes, pueden escoger la fecha de donde hasta donde la rutina será visible, y los ejercicios y dificultad que conlleva dicha rutina.
    -   Enfoques
        -   Los enfoques es una ímagen acompañada de un titulo que hace referencia a la parte del cuerpo que se trabaja o la utilización de implementos, cada una de las creadas por los administradores o entrenadores estarán disponibles para escogerlas en las rutinas que se desean crear.
    -   Ejercicios
        -   Los ejercicios son las actividades que se pueden realizar en el gimnasio, está acompañado de un título o nombre del ejercicio, y una breve explicación textual del ejercicio, al crear nuevos ejercicios estarán disponibles para asignarlas a rutinas nuevas que se deseen crear.
-   **Gestion de Recursos**
    -   Productos
        -   Visualización de los diferentes productos disponibles en el gimnasio.
        -   Creación, edición y eliminación de productos, los administradores pueden registrar los productos que tienen disponibles en el gimnasio pueden añadir la cantidad inicial del producto y los disponibles (al registrar usualmente ambas cantidades son la misma la primera vez), el apartado de disponibles se reduce cuando se vende un producto y se registra en los ingresos diarios.
    -   Membresías
        -   Visualización de las membresías creadas por el administrador.
        -   Creación, edición y eliminación de membresías, los administradores pueden registrar nuevas membresías al momento de ser creadas los clientes pueden visualizarlas para la compra de las mismas, va acompañado de un titulo o nombre de membresía, una descripción opcional, la duración en días y el precio en COP (peso colombiano).
    -   Categorías
        -   Visualización de categorias/conceptos creados por el administrador
        -   Edición y eliminación de categorias, las categorias son creadas en los modulos Ingresos Diarios, Productos y Ejercicios, el propósito de este módulo es permitirle al administrador corregir el nombre de una categoría que de pronto quede mal redactada, o eliminarla si no la necesitará.
-   **Pasarela de pagos**
    Los clientes pueden comprar membresías a través de la página, un cliente nuevo le salen las diferentes opciones de membresías a adquirir, al hacer el pago al ser un modulo de pruebas se selecciona de banco pse, Banco Union Colombiano

    Cuando ya son clientes frecuentes cuando tienen una membresía a punto de vencer en el perfil o dashboard aparece que tiene el estado en pendiente al presionar allí puede pagar su membresía
## Instalación y uso del proyecto de manera local

**Prerequisitos**

NodeJs, puedes instalar la última versión de nodejs en el siguiente enlace [Descargar](https://nodejs.org/es/download).

Composer, puede instalar la última versión de composer en el siguiente enlace [Descargar](https://getcomposer.org/download/).

XAMMP, puede instalar la última versión de xammp en el siguiente enlace [Descargar](https://www.apachefriends.org/es/download.html).

PostgreSQL, puede instalar la última versión de postgresql en el siguiente enlace [Descargar](https://www.enterprisedb.com/downloads/postgres-postgresql-downloads).

Mailtrap, es un servicio smtp para servidores de pruebas [Página oficial](https://mailtrap.io/).

**Instalación**

Clone el repositorio en su equipo.

Se debe crear una base de datos postgreSQL con pgadmin, por defecto viene instalado al terminar la instalación, las credenciales de la base de datos van en el archivo .env del proyecto si no tiene uno creelo y copie todas las lineas que están en el archivo .env.example

Al registrarse el Mailtrap se te ofrecen también unas credenciales de configuración del servicio smtp para el proyecto, ubicarlos en el archivo .env

abra la carpeta del proyecto y ubicado en la raíz del directorio abra 1 terminal de comandos (recomnedación descargar Git Bash), ejecutar los siguientes comandos

-   **Comandos a ejecutar una sola vez**

    -   npm install
    -   composer install
    -   npm run build
    -   php artisan migrate --seed

-   **Comandos a ejecutar para iniciar la aplicación**
    Se necesitan 2 consolas más además de la primera solicitada para ejecutar unos servicios automáticos del servidor

    consola 1 - ejecución del servidor web local

    -   php artisan serve

    consola 2 - ejecución del programador de tareas del programa

    -   php artisan schedule:work

    consola 3 - ejecución de la cola de trabajo del programa (para servicios como el envio de emails)

    -   php artisan queue:work

**Uso de la aplicación**

Abra un navegador y escriba la url más el puerto que te ofrece la consola donde ejecutaste el comando **php artisan serve**, el usuario de prueba es admin@gmail.com, contraseña: password

## Manual de Usuario

Pendiente de especificación
