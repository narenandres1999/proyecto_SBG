<?php

namespace Database\Seeders;

use App\Models\Membresia;
use App\Models\PseBanco;
use App\Models\TypeIdentification;
use App\Models\Usuario;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;

class ProductionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Accept' => 'application/json'
        ])->post(env('PAYU_BASE_URL') . 'payments-api/4.0/service.cgi', [
            'language' => 'es',
            'command' => 'GET_BANKS_LIST',
            'merchant' => [
                'apiLogin' => env('PAYU_SECRET'),
                'apiKey' => env('PAYU_KEY')
            ],
            'test' => true,
            'bankListInformation' => [
                'paymentMethod' => 'PSE',
                'paymentCountry' => 'CO'
            ]
        ]);
        foreach ($response->json()['banks'] as $banco) {
            PseBanco::firstOrCreate($banco);
        }
        $this->call([RoleSeeder::class, CategoriaSeeder::class, MembresiaSeeder::class]);
        TypeIdentification::create(['codigo' => 'CC', 'nombre_documento' => 'Cédula de ciudadanía']);
        TypeIdentification::create(['codigo' => 'CE', 'nombre_documento' => 'Cédula de extranjería']);
        TypeIdentification::create(['codigo' => 'TI', 'nombre_documento' => 'Tarjeta de identidad']);
        TypeIdentification::create(['codigo' => 'DE', 'nombre_documento' => 'Documento de identificación']);
        TypeIdentification::create(['codigo' => 'NIT', 'nombre_documento' => 'Número de Identificación']);
        TypeIdentification::create(['codigo' => 'PP', 'nombre_documento' => 'Pasaporte']);
        TypeIdentification::create(['codigo' => 'RC', 'nombre_documento' => 'Registro civil de nacimiento']);

        Usuario::firstOrCreate([
            'email' => "sportbodygym@gmail.com",
            'password' => Hash::make('07269903980'),
            'telefono' => '3218485878',
            'fecha_nacimiento' => '1999-07-26',
            'nombre' => 'Administrador SBG',
            'apellidos' => 'SBG',
            'email_verified_at' => now(),
            'direccion' => 'Calle 2 #4-45',
            'membresia_id' => null,
            'proxima_generacion' => null,
            'suscripcion_activa' => 0,
            'documento' => null,
            'type_identification_id' => null
        ])->assignRole('Admin');
    }
}
