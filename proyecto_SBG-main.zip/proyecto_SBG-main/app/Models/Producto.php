<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use App\Models\Ingresos_diario;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;



class Producto extends Model
{
    use HasFactory;
    use SoftDeletes;
    // Toca indicar que la clave primaria es diferente a la de por defecto
    protected $primaryKey = 'sku';
    // Esta propiedad es para indicarle que no se genera de manera automatica
    public $incrementing = false;
    // Esta propiedad es para indicar que la clave primaria es de tipo string y no int (el por defecto)
    protected $keyType = 'string';
    protected $guarded = [];
    // Definición de los métodos de relaciones
    public function ingresosDiarios(): HasMany
    {
        return $this->hasMany(Ingresos_diario::class);
    }
    public function categoria():BelongsTo
    {
        return $this->belongsTo(Categoria::class);
    }

}
