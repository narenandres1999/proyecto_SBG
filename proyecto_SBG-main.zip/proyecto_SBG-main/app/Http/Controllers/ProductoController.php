<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreProductoRequest;
use App\Models\Categoria;
use Illuminate\Http\Request;
use App\Models\Producto;
use Exception;
use Illuminate\Database\QueryException;

class ProductoController extends Controller
{
    // ruta = /productos/
    public function index(Request $r)
    {
        $search = $r->search;
        $productos = Producto::where('sku', 'ilike', '%' . $search . '%')
            ->orwhere('nombre', 'ilike', '%' . $search . '%')
            ->orWhereRelation('categoria', 'nombre', 'ilike', '%' . $search . '%')
            ->orderBy('nombre')
            ->paginate(5);
        return view('products.index', compact('productos', 'search'));
    }
    // ruta = /productos/create
    public function create()
    {
        $categorias = Categoria::where('tipo', 'producto')->orderBy('nombre')->get();
        return view('products.create', compact('categorias'));
    }
    // ruta = /productos/
    public function store(StoreProductoRequest $request)
    {
        if (Producto::find($request->sku)) {
            return back()->withErrors(['sku' => 'Ya existe un producto con ese código'])->withInput($request->all());
        }
        if ($request->categoria_id == 'add-category') {
            if (!$request->nueva_categoria) {
                return back()->withErrors(['nueva_categoria' => 'Agrege el nombre de la nueva categoría'])->withInput($request->all());
            }
            $nueva_categoria = Categoria::create([
                'nombre' => $request->nueva_categoria,
                'tipo' => 'producto'
            ]);
            $nueva_categoria->productos()->create($request->except(['nueva_categoria', 'categoria_id']));
        } else {
            Producto::create($request->except(['nueva_categoria']));
        }
        // Producto::create($request->except('nueva_categoria'));
        return redirect()->route('productos.index')->with('alert', ['type' => 'success']);
    }
    // ruta = /productos/{producto}
    public function show(Producto $producto)
    {
        return view('products.show', compact('producto'));
    }

    public function edit(Producto $producto)
    {
        $categorias = Categoria::where('tipo', 'producto')->orderBy('nombre')->get();
        return view('products.edit', compact('producto', 'categorias'));
    }

    // ruta = /productos/{producto}
    public function update(StoreProductoRequest $request, Producto $producto)
    {
        try {
            if ($request->categoria_id == 'add-category') {
                if (!$request->nueva_categoria) {
                    return back()->withErrors(['nueva_categoria' => 'Agrege el nombre de la nueva categoría'])->withInput($request->all());
                }
                $nueva_categoria = Categoria::create([
                    'nombre' => $request->nueva_categoria,
                    'tipo' => 'producto'
                ]);
                $request['categoria_id'] = $nueva_categoria->id;
                $producto->update($request->except(['nueva_categoria']));
            } else {
                $producto->update($request->except(['nueva_categoria']));
            }
            return redirect()->route('productos.index')->with('alert', ['type' => 'success']);
        } catch (Exception $e) {
            throw $e;
        }
    }
    // ruta = /producto/{producto}
    public function destroy(Producto $producto)
    {
        $producto->delete();
        return back();
    }
}
