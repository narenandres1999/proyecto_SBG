<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('historiales', function (Blueprint $table) {
            $table->id();
            $table->date('fecha_pago');
            $table->integer('valor_hora');
            $table->date('fecha_desde');
            $table->date('fecha_hasta');
            $table->integer('total_horas');
            $table->integer('valor_pagado');
            $table->timestamps();
            // Relaciones
            $table->foreignId('reporte_id')->nullOnDelete()->nullable()->constrained();
            $table->uuid('usuario_id')->nullOnDelete();
            $table->foreign('usuario_id')->references('id')->on('usuarios');
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('historiales');
    }
};
