<?php

namespace App\Http\Livewire\TrainersComponents;

use App\Models\Asistencia;
use App\Models\Historiale;
use App\Models\Usuario;
use Carbon\Carbon;
use Livewire\Component;

class PaymentCreate extends Component
{
    public $entrenadores = null;
    public string $entrenador_seleccionado = '';
    public $desde = null;
    public $hasta = null;
    public string $valor_hora = "";
    public int $valor_total = 0;
    public int $horas_laburadas = 0;

    public function updated()
    {
        if ($this->entrenador_seleccionado && $this->desde && $this->hasta) {
            // $desde = Carbon::parse($this->desde);
            // $hasta = Carbon::parse($this->hasta);
            $total_horas = 0;
            $asistencias = Asistencia::where('usuario_id', $this->entrenador_seleccionado)
                ->whereDate('start_date', '>=', $this->desde)
                ->whereDate('start_date', '<=', $this->hasta)
                ->get();

            foreach ($asistencias as $asistencia) {
                $total_horas += $asistencia->horas;
            }
            $this->horas_laburadas = $total_horas;
            if ($this->valor_hora) {
                $this->valor_total = intval($this->valor_hora) * $total_horas;
            }
        }
    }
    public function updatedEntrenadorSeleccionado()
    {
        if($this->entrenador_seleccionado){
            $entrenador = Usuario::role('Entrenador')
                ->where('id', $this->entrenador_seleccionado)
                ->first();
            $this->valor_hora = $entrenador->historiales->last() ? $entrenador->historiales->last()->valor_hora : 0;
            $this->valor_total = intval($this->valor_hora) * $this->horas_laburadas;
        }
    }
    public function render()
    {
        return view('livewire.trainers-components.payment-create');
    }
}
