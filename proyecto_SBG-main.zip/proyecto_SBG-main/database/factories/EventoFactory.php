<?php

namespace Database\Factories;

use App\Models\Usuario;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Evento>
 */
class EventoFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $usuarios = Usuario::all()->modelKeys();
        return [
            'titulo' => $this->faker->jobTitle(),
            'contenido' => $this->faker->paragraph(),
            'imagen' => null,
            'fecha_evento' => $this->faker->dateTimeBetween('-2 week', 'now'),
            'fecha_desde' => $this->faker->dateTimeBetween('-2 week', 'now'),
            'fecha_hasta' => $this->faker->dateTimeBetween('-2 week', '+1 week'),
            'usuario_id' => $this->faker->randomElement($usuarios),
        ];
    }
}
