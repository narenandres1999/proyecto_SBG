<?php

namespace App\View\Components\forms;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class inputFecha extends Component
{
    /**
     * Create a new component instance.
     */
    public function __construct(
        public string $name,
        public string $namePlaceholder,
        public string $nameLabel,
        public string $inputType,
        public string $defaultValue,
        public string $nameId,
        public string $model = '',
        public bool $disabled = false
    ) {}

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        return view('components.forms.input-fecha');
    }
}
