<?php

namespace App\Http\Controllers;

use App\Http\Requests\AntropometricaRequest;
use App\Mail\AntopometricaMailable;
use Illuminate\Http\Request;
use App\Models\Antropometrica;
use Illuminate\Database\Eloquent\Collection;
use App\Models\Usuario;
use Exception;
use Illuminate\Support\Facades\Mail;

class AntropometricaController extends Controller
{
    public function index(String $usuario)
    {
        /*
        $antropometrica = Antropometrica::where('usuario_id',$usuario)->paginate();
        return $antropometrica;
        */
        return view('anthropometric.index', compact('usuario'));
    }

    public function create(Usuario $usuario)
    {

        return view('anthropometric.create', compact('usuario'));
    }

    public function store(AntropometricaRequest $request, Usuario $usuario)
    {
        $request['usuario_id'] = $usuario->id;
        $antropometrica = Antropometrica::create($request->all());
        Mail::to($usuario)->send(new AntopometricaMailable($usuario));
        return redirect()->route('usuarios.show', $usuario)->with('alert', ['type' => 'success']);
    }

    public function show(string $antropometrica)
    {
        $antropometrica = Antropometrica::find($antropometrica);
        return $antropometrica;
    }

    public function edit(string $antropometrica)
    {
        $antropometrica = Antropometrica::find($antropometrica);
        return view('anthropometric.edit', compact('antropometrica'));
    }

    public function update(AntropometricaRequest $request, Antropometrica $antropometrica)
    {
        try{
            $antropometrica->update($request->all());
            return redirect()->route('usuarios.show', ['usuario' => $antropometrica->usuario_id])->with('alert', ['type' => 'info']);
        }
        catch(Exception $e){
            throw $e;
            return back()->with('alert',['type'=>'error']);
        }
    }

    public function destroy(string $antropometrica)
    {
        $antropometrica = Antropometrica::find($antropometrica);
        $antropometrica->forceDelete();
    }
}
