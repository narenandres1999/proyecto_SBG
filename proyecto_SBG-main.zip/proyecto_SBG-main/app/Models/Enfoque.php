<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Ejercicio;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use App\Models\Rutina;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Enfoque extends Model
{
    use HasFactory;

    protected $guarded = [];

    // Definición de los métodos de relaciones
    public function ejercicios(): BelongsToMany
    {
        return $this->belongsToMany(Ejercicio::class)->withPivot('repeticiones', 'series','rutina_id');
    }
    public function rutinas(): HasMany
    {
        return $this->hasMany(Rutina::class);
    }
}
