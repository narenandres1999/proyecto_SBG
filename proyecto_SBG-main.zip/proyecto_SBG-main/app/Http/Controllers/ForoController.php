<?php

namespace App\Http\Controllers;

use App\Models\Foro;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class ForoController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->search;
        $foros = Foro::where('titulo', 'ilike', '%' . $search . '%')
            ->orwhere('descripcion', 'ilike', '%' . $search . '%')
            ->paginate(5);
        return view('blog.index', compact('foros'));
    }

    
    public function create()
    {
        return view('blog.create');
    }
    public function store(Request $request)
    {
        try{
            $this->validate($request,[
                'titulo' => 'required',
                'descripcion' => 'required'
            ]);
            $request['usuario_id'] = Auth::user()->id;
            $foro = Foro::create($request->all());
            return redirect()->route('foro.show',$foro)->with('alert',['type'=> 'success']);
        }catch(Exception $e){
            throw $e;
            return back()->with('alert',['type' => 'error']);
        }
    }
    public function show(Foro $foro)
    {
        return view('blog.show', compact('foro'));
    }
    public function edit(Request $request, Foro $foro)
    {
        return view('blog.edit',compact('foro'));
    }
    public function update(Request $request, Foro $foro)
    {
        try{
            $this->validate($request,[
                'titulo' => 'required',
                'descripcion' => 'required'
            ]);
            $foro->update($request->all());
            return redirect()->route('foro.show',$foro)->with('alert',['type'=> 'success']);
        }catch(Exception $e){
            throw $e;
            return back()->with('alert',['type' => 'error']);
        }
    }
    public function destroy(Foro $foro)
    {
        $foro->delete();
        return redirect()->route('foro.index');
    }
}
