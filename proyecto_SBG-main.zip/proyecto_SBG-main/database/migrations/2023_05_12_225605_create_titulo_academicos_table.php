<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('titulo_academicos', function (Blueprint $table) {
            $table->id();
            $table->string('titulo_academico');
            $table->timestamps();
            $table->uuid('usuario_id')->nullOnDelete();
            $table->foreign('usuario_id')->references('id')->on('usuarios');
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('titulo_academicos');
    }
};
