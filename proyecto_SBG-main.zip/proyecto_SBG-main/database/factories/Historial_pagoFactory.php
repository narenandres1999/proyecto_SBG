<?php

namespace Database\Factories;

use App\Models\Reporte;
use App\Models\Usuario;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Historial_Pago>
 */
class Historial_pagoFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $reportes = Reporte::all()->modelKeys();
        $usuarios = Usuario::all()->modelKeys();
        $usuario_id = $this->faker->randomElement($usuarios);
        $membresia = Usuario::where('id',$usuario_id)->first()->membresia;
        $membresia_id = $membresia->id;
        $valor = $membresia->valor;
        return [
            // Acomode el archivo que no lo detecta
            'fecha_limite' => now(),
            'mes_factura' => $this->faker->monthName(),
            'valor' => $valor,
            'modalidad' => $this->faker->randomElement(['Efectivo','Digital']),
            'estado' => "Pagado",
            'reporte_id' =>$this->faker->randomElement($reportes),
            'membresia_id' => $membresia_id,
            'usuario_id' => $usuario_id
        ];
    }
}
