<?php

namespace App\Http\Livewire\ApproachComponents;
use App\Models\Enfoque;
use Livewire\Component;

class Form extends Component
{
    public String $selectedImage = '';
    public String $valueTitulo = '';
    public String $image;
    // estas variables se pediran al componente en el sitio donde lo desees renderizar
    // Se pasa un objeto enfoque llegando el caso que se necesite dar para editar
    public $enfoque = null;
    // Se pasa la ruta nombrada de donde se enviara la peticion ejemplo 'enfoque.store'
    public String $routeAction = '';
    // Se pasa el método http en el cual se enviara la petición POST o PUT
    public String $method = 'POST';
    public function mount(){
        if ($this->enfoque){
            $this->selectedImage = $this->enfoque->avatar;
            $this->valueTitulo = $this->enfoque->titulo;
            $this->image = $this->enfoque->avatar;
        }
    }
    public function updatedSelectedImage($value){
        $this->image = $value;
    }
    public function render()
    {
        return view('livewire.approach-components.form');
    }
}
