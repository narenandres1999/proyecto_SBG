<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreMembresiaRequest;
use App\Http\Requests\UpdateMembresiaRequest;
use App\Models\Membresia;
use Illuminate\Http\Request;

class MembresiaController extends Controller
{
    public function index(){
        $membresias = Membresia::all();
        return view('memberships.index',compact('membresias'));
    }

    public function create(){
        return view('memberships.create');
    }
    public function edit(Membresia $membresia){
        return view('memberships/edit',compact('membresia'));
    }
    public function store(StoreMembresiaRequest $r){
        $membresia = Membresia::create($r->all());
        $membresia->fresh();
        return redirect()->route('membresia.index')->with('alert',['type' => 'success']);
    }

    public function update(UpdateMembresiaRequest $r,Membresia $membresia){
        $membresia->update($r->all());
        $membresia->fresh();
        return back()->with('alert',['type' => 'info']);
    }
    public function destroy(Membresia $membresia){
        $membresia->delete;
    }
    public function shopping()
    {
        $membresias = Membresia::all();
        return view('memberships.buy',compact('membresias'));
    }
}
