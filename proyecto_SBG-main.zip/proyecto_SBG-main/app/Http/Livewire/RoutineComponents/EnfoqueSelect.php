<?php

namespace App\Http\Livewire\RoutineComponents;

use App\Http\Resources\RutinaResource;
use App\Models\Enfoque;
use Livewire\Component;
use App\Models\Rutina;

class EnfoqueSelect extends Component
{
    public string $selectedApproach = '';
    public $previewApproach = null;
    public $rutina;
    public $approachList = '';
    public function mount()
    {

        $this->approachList = Enfoque::orderBy('titulo')->get();
        if ($this->rutina) {
            $this->selectedApproach = $this->rutina->enfoque->id;
            $this->previewApproach = $this->rutina->enfoque;
        }
    }
    public function updatedSelectedApproach($value)
    {
        if ($value) {
            $this->previewApproach = Enfoque::find($value);
        } else {
        }
    }
    public function render()
    {
        return view('livewire.routine-components.enfoque-select');
    }
}
