<?php

namespace Database\Factories;

use App\Models\Usuario;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\TituloAcademico>
 */
class TituloAcademicoFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $usuarios = Usuario::all()->modelKeys();
        return [
            'titulo_academico' => $this->faker->jobTitle(),
            'usuario_id' => $this->faker->randomElement($usuarios)
        ];
    }
}
