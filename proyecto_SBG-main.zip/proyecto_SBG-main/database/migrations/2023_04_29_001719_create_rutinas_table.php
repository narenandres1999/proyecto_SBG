<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('rutinas', function (Blueprint $table) {
            $table->id();
            $table->string('dificultad');
            $table->dateTime('start_date');
            $table->dateTime('end_date');
            $table->softDeletes();
            $table->timestamps();
            // Relaciones
            $table->foreignId('enfoque_id')->cascadeOnDelete()->constrained();
            $table->uuid('usuario_id')->nullOnDelete();
            $table->foreign('usuario_id')->references('id')->on('usuarios');
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('rutinas');
    }
};
